# SRTM-Downloader
Clone the repository with:

$ git clone --recurse-submodules https://github.com/hdus/SRTM-Downloader

Update submodule with:

$ git submodule update --remote about
