import sys, os, os.path
import datetime, time
import logging
import configparser
from typing import TYPE_CHECKING
import psycopg2, psycopg2.extras
from psycopg2 import sql
from .mylib import *
from .rassam import DBConnection, UsePlugin
import re
#========================================================

class DataAccess:

    usePlugin = UsePlugin()
    dBConnection = None


    # Get a connection to the database.
    def getConn(self):
        self.usePlugin.checkProjVariables()
        try:
            self.dBConnection = DBConnection(self.usePlugin.getValue('db_host'), '5432', 'electricity')
            conn = self.dBConnection.getConn()
            conn.autocommit = True
            return conn
        except Exception as e:
            logging.error(e)
            return False


    def updatePaths(self):
        try:
            cur = self.getConn().cursor()
            query = sql.SQL("""
                    SELECT update_paths();
                """)
            cur.execute(query)
            return True
        except Exception as e:
            # No logging. This is broken! <<<<<<<<<<<<<<<<<<<<<<<<<
            logging.error(e)
            return False
            
            
    def getEngNameOfTable(self, perName):
        try:
            cur = self.getConn().cursor()
            cur.execute("""
                    SELECT
                        smdatasetname
                    FROM
                        public.smregister
                    WHERE
                        smtablename = %s
                """, (perName,))
            data = cur.fetchone()
            if data:
                smdatasetname = data[0]
            else:
                smdatasetname = None
            return smdatasetname
        except Exception as e:
            logging.error(e)
            return False


    def getFaNameOfCol(self, name):
        try:
            cur = self.getConn().cursor()
            cur.execute("""
                    SELECT columnname_en2fa(%s);
                """, (name,))
            data = cur.fetchone()
            return data[0]
        except Exception as e:
            logging.error(e)
            return False


    def getFeatureInfo(self, tableName, smid):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT * FROM get_net_info(get_node_feeder(smid2nodeid((%s, %s))));
                """, (tableName, smid))
            row = cur.fetchone()
            return row
        except Exception as e:
            logging.error(e)
            return False


    def getFeatureIDs(self, tableName, smid):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT * FROM get_feature_IDs(%s, %s);
                """, (tableName, smid))
            featureID = cur.fetchone()
            complete_featureID = self.completeFeatureIDs(featureID , tableName)
            return complete_featureID
        except Exception as e:
            logging.error(e)
            return None

    def completeFeatureIDs(self , featureID , tableName):
        # try:
        #     featureID['fa_name'] = self.getTableName_Tr(tableName)
        #     mdsComplete = self.getMdsubCode(featureID['mdsub'])
        #     featureID['local_mdsub_name'] = mdsComplete[0]
        #     featureID['local_mdsub_code'] = mdsComplete[1]
        #     featureID['feeder_code'] = self.getFeederCode(featureID['mv_feeder'])
        try:
            featureID['fa_name'] = self.getTableName_Tr(tableName)
            mdsComplete = self.getMdsubCode(featureID['mdsub'])
            if mdsComplete :
                featureID['local_mdsub_name'] = mdsComplete[0]
                featureID['local_mdsub_code'] = mdsComplete[1]
            else:
                featureID['local_mdsub_name'] = ""
                featureID['local_mdsub_code'] = ""
            featureID['feeder_code'] = self.getFeederCode(featureID['mv_feeder'])

            return featureID
        except Exception as e:
            logging.error(e)
            return None

    def getTableName_Tr(self,tableName):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = """SELECT table_fa FROM translate_tables where table_en = \'{}\';""".format(tableName)
            cur.execute(query)
            fa_table_name = cur.fetchone()
            return fa_table_name['table_fa']
        except Exception as e:
            logging.error(e)
            return False
        
    def getMdsubCode(self , mdSubDetail):
        cur = self.getConn().cursor()
        sky_check = re.search("(PL)*" , str(mdSubDetail))
        sky_other_check = re.search("(ELA)*" , str(mdSubDetail))
        print(str(mdSubDetail))
        if sky_check or sky_other_check:
            query = """SELECT pl_mds_nam , loc_cod from pl_mdsub where "pl_mds_cod" = \'{}\'""".format(str(mdSubDetail))
        else:
            query = """SELECT loc_nam , loc_cod from pd_mdsub where "ID" = \'{}\'""".format(str(mdSubDetail))

        cur.execute(query)
        result = cur.fetchone()
        return result

    
    def getFeederCode(self , mv_feeder):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = """SELECT feeder_code FROM mv_feeder where "name" = \'{}\';""".format(mv_feeder)
            cur.execute(query)
            fa_table_name = cur.fetchone()
            return fa_table_name['feeder_code']
        except Exception as e:
            logging.error(e)
            return False  
        
    def getFeaturesTypes(self, tableName, smid, analysisType):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT tablename_en2fa(table_name) AS table_name_fa, table_name, count FROM (
                    SELECT table_name, count(*) AS count FROM UNNEST(get_features(%s, %s, %s))
                    GROUP BY table_name
                    ORDER BY count DESC
                ) AS t1;
                """, (analysisType, tableName, smid))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getFeederFeaturesList(self, tableName, smid, featureType, analysisType):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT * FROM {}
                WHERE
                    smid IN (
                        SELECT smid FROM UNNEST(get_features(%s, %s, %s, %s))
                    );
                """.format(featureType), (analysisType, tableName, smid, featureType))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getFeederSmidList(self, tableName, smid, featureType, analysisType):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT smid FROM {}
                WHERE
                    smid IN (
                        SELECT smid FROM UNNEST(get_features(%s, %s, %s, %s))
                    );
                """.format(featureType), (analysisType, tableName, smid, featureType))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False
        
    def getFeatureNodes(self, tableName, smid, analysisType):
        try:
            cur = self.getConn().cursor()
            cur.execute("""
                    SELECT DISTINCT UNNEST(smid2nodeids(table_name, smid)) FROM UNNEST(get_features(%s, %s, %s))
                """, (analysisType, tableName, smid,))
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            logging.error(e)
            return False


    def getEngNameOfTable(self, perName):
        cursor = self.getConn().cursor()
        cursor.execute("""
                SELECT
                    smdatasetname
                FROM
                    public.smregister
                WHERE
                    smtablename = %s
            """, (perName,))
        data = cursor.fetchone()
        if data:
            smdatasetname = data[0]
        else:
            smdatasetname = None
        return smdatasetname

    def getAllFaCols(self, tableName):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT DISTINCT ON (c.column_name)
                    c.column_name,
                    s.smfieldcaption 
                from information_schema.tables t
                inner join information_schema.columns c on c.table_name = t.table_name 
                                                and c.table_schema = t.table_schema
                INNER JOIN smfieldinfo s ON (c.column_name = s.smfieldname)
                where 
                    t.table_name = %s
                    AND t.table_schema = 'public'
                """, (tableName,))
            rows = cur.fetchall()
            names = {}
            for row in rows:
                names[row['column_name']] = row['smfieldcaption']
            return names
        except Exception as e:
            logging.error(e)
            return False

    
    def featureExists(self, tableName, smid):
        try:
            cur = self.getConn().cursor()
            cur.execute("""
                    SELECT EXISTS (SELECT * FROM brp_feature_node WHERE table_name = %s AND smid = %s)
                """, (tableName, smid,))
            data = cur.fetchone()
            return data[0]
        except Exception as e:
            logging.error(e)
            return False


    def getLineDist(self, tableName, smid):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT * FROM get_line_dist(%s, %s);
                """, (tableName, smid,))
            data = cur.fetchone()
            return data
        except Exception as e:
            logging.error(e)
            return False


    def getLeafNodes(self, tableName, smid):
        try:
            cur = self.getConn().cursor()
            cur.execute("""
                    SELECT get_leaf_nodes(%s, %s);
                """, (tableName, smid,))
            data = cur.fetchone()
            return data[0]
        except Exception as e:
            logging.error(e)
            return False
        
        
    def getUsersGroup(self , userName):
        groups =[]
        try:
            cur = self.getConn().cursor()
            cur.execute("""
                    SELECT
                        r1.rolname as "groups"
                    FROM
                            pg_catalog.pg_roles r
                    JOIN pg_catalog.pg_auth_members m ON (m.member = r.oid)
                    JOIN pg_roles r1 ON (m.roleid = r1.oid)
                    WHERE 
                        r.rolname = %s
                    """, (userName,))
            rows = cur.fetchall()
            groups = [group[0] for group in rows]
            return groups
        except Exception as e:
            logging.error(e)
            return groups