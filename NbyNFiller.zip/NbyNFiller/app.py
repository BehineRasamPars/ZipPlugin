import sys
from .DataAccess import DataAccess
from .mylib import *
from .rassam import *
from .resources import *
from PyQt5 import QtWidgets, QtGui, QtCore
from qgis.utils import iface, Qgis
import xlwt
from qgis.PyQt.QtWidgets import QTableWidgetItem
from .jalaali import Jalaali
from qgis.core import QgsRectangle
import re
import psycopg2.extras
from .rassam import *
import json


class NbyNFiller(QtWidgets.QMainWindow):

    dataAccess = None
    usePlugin = None
    
    def __init__(self):
        super().__init__()
        self.dataAccess = DataAccess()
    
    def cir_seg_node(self):
        self.run()
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Warning)
        msgBox.setText('آیا روابط روی تکه مدارهای انتخاب شده انجام گیرد یا روی تمام تکه مدارهای پایگاه داده؟')
        msgBox.setWindowTitle("توجه")
        msgBox.addButton(QtWidgets.QPushButton("تمام تکه مدارهای پایگاه داده"), QtWidgets.QMessageBox.YesRole)
        msgBox.addButton(QtWidgets.QPushButton("تکه مدارهای انتخاب شده"), QtWidgets.QMessageBox.NoRole)
        returnValue = msgBox.exec_()

        typ = 'FALSE'
        tbl1 = self.findLayer('public','cir_seg')
        codes = '['
        if returnValue == 0: # all the database
            typ = 'TRUE'
            for x in tbl1.getFeatures(): 
                codes = codes + "'" + x['ciseg_id'] + "',"
        else: # selected records
            if len(tbl1.selectedFeatures()) == 0:
                iface.messageBar().pushMessage("Warning", "رکوردی از جدول تکه مدار انتخاب نشده است",level = Qgis.Warning, duration = 5) 
                return
            for x in tbl1.selectedFeatures():
                codes = codes + "'" + x['ciseg_id'] + "',"

        codes = codes[:-1] + ']'

        cursor = self.conn.cursor()
        query = "select n_by_n_relation_t3('cir_seg_node','cir_seg','node','ciseg_id','node_id', ARRAY "+codes+","+typ+")"
        print(query)
        cursor.execute(query)
        self.conn.commit()
        iface.messageBar().pushMessage("Info", "روابط بین جدول های تکه مدار و گره برقرار شد",level = Qgis.Info, duration = 5) 
        
    def ovpat_seg_tower(self):
        self.run()
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Warning)
        msgBox.setText('آیا روابط روی تکه مسیرهای هوایی انتخاب شده انجام گیرد یا روی تمام تکه مسیرهای هوایی پایگاه داده؟')
        msgBox.setWindowTitle("توجه")
        msgBox.addButton(QtWidgets.QPushButton("تمام تکه مسیرهای هوایی پایگاه داده"), QtWidgets.QMessageBox.YesRole)
        msgBox.addButton(QtWidgets.QPushButton("تکه مسیرهای هوایی انتخاب شده"), QtWidgets.QMessageBox.NoRole)
        returnValue = msgBox.exec_()

        typ = 'FALSE'
        tbl1 = self.findLayer('public','ovpat_seg')
        codes = '['
        if returnValue == 0: # all the database
            typ = 'TRUE'
            for x in tbl1.getFeatures(): 
                codes = codes + "'" + x['ovpasg_id'] + "',"
        else: # selected records
            if len(tbl1.selectedFeatures()) == 0:
                iface.messageBar().pushMessage("Warning", "رکوردی از جدول تکه مسیرهوایی انتخاب نشده است",level = Qgis.Warning, duration = 5) 
                return
            for x in tbl1.selectedFeatures():
                codes = codes + "'" + x['ovpasg_id'] + "',"

        codes = codes[:-1] + ']'

        cursor = self.conn.cursor()
        query = "select n_by_n_relation_t3('tower_ovpat_seg','ovpat_seg','tower','ovpasg_id','tower_id', ARRAY "+codes+","+typ+")"
        print(query)
        cursor.execute(query)
        self.conn.commit()
        iface.messageBar().pushMessage("Info", "روابط بین جدول های تکه مسیر هوایی و دکل برقرار شد",level = Qgis.Info, duration = 5) 
        
    def cir_seg_cisegmi(self):     
        self.run()
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Warning)
        msgBox.setText('آیا روابط روی امپدانس متقابل های تکه مدار انتخاب شده انجام گیرد یا روی تمام امپدانس متقابل های تکه مدار پایگاه داده؟')
        msgBox.setWindowTitle("توجه")
        msgBox.addButton(QtWidgets.QPushButton("تمام امپدانس متقابل های تکه مدار پایگاه داده"), QtWidgets.QMessageBox.YesRole)
        msgBox.addButton(QtWidgets.QPushButton("امپدانس متقابل های تکه مدار انتخاب شده"), QtWidgets.QMessageBox.NoRole)
        returnValue = msgBox.exec_()

        typ = 'FALSE'
        tbl1 = self.findLayer('public','cisegmi')
        codes = '['
        if returnValue == 0: # all the database
            typ = 'TRUE'
            for x in tbl1.getFeatures(): 
                codes = codes + "'" + x['cisegmi_id'] + "',"
        else: # selected records
            if len(tbl1.selectedFeatures()) == 0:
                iface.messageBar().pushMessage("Warning", "رکوردی از جدول امپدانس متقابل تکه مدار انتخاب نشده است",level = Qgis.Warning, duration = 5) 
                return
            for x in tbl1.selectedFeatures():
                codes = codes + "'" + x['cisegmi_id'] + "',"

        codes = codes[:-1] + ']'

        cursor = self.conn.cursor()
        query = "select n_by_n_relation_t2('cir_seg_cisegmi','cisegmi','cisegmi_id','ciseg_id',ARRAY ['ciseg1_id','ciseg2_id'], ARRAY "+codes+","+typ+")"
        cursor.execute(query)
        self.conn.commit()
        iface.messageBar().pushMessage("Info", "روابط بین جدول های تکه مدار و امپدانس متقابل تکه مدار برقرار شد",level = Qgis.Info, duration = 5) 
        
    def winding_impedanc(self):
        self.run()
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Warning)
        msgBox.setText('آیا روابط روی امپدانس درصدهای انتخاب شده انجام گیرد یا روی تمام امپدانس درصدهای پایگاه داده؟')
        msgBox.setWindowTitle("توجه")
        msgBox.addButton(QtWidgets.QPushButton("تمام امپدانس درصدهای پایگاه داده"), QtWidgets.QMessageBox.YesRole)
        msgBox.addButton(QtWidgets.QPushButton("امپدانس درصدهای انتخاب شده"), QtWidgets.QMessageBox.NoRole)
        returnValue = msgBox.exec_()

        typ = 'FALSE'
        tbl1 = self.findLayer('public','impedanc')
        codes = '['
        if returnValue == 0: # all the database
            typ = 'TRUE'
            for x in tbl1.getFeatures(): 
                codes = codes + "'" + x['impedanc_id'] + "',"
        else: # selected records
            if len(tbl1.selectedFeatures()) == 0:
                iface.messageBar().pushMessage("Warning", "رکوردی از جدول امپدانس درصد انتخاب نشده است",level = Qgis.Warning, duration = 5) 
                return
            for x in tbl1.selectedFeatures():
                codes = codes + "'" + x['impedanc_id'] + "',"

        codes = codes[:-1] + ']'

        cursor = self.conn.cursor()
        query = "select n_by_n_relation_t2('winding_impedanc','impedanc','impedanc_id','wind_id',ARRAY ['term1_id','term2_id'], ARRAY "+codes+","+typ+")"
        cursor.execute(query)
        self.conn.commit()
        iface.messageBar().pushMessage("Info", "روابط بین جدول های سیم پیچ و امپدانس درصد برقرار شد",level = Qgis.Info, duration = 5) 

    def com_link_rtu(self):
        self.run()
        cursor = self.conn.cursor()
        tbl1 = self.findLayer('public','com_link')
        tbl2 = self.findLayer('public','rtu')
        if len(tbl1.selectedFeatures()) == 0 or len(tbl2.selectedFeatures()) == 0:
            iface.messageBar().pushMessage("Warning", "از هر دو جدول باید رکوردهایی انتخاب شده باشند",level = Qgis.Warning, duration = 5) 
            return

        codes1 = '['
        for x in tbl1.selectedFeatures():
            codes1 = codes1 + "'" + x['colin_id'] + "',"
        codes1 = codes1[:-1] + ']'
        codes2 = '['
        for x in tbl2.selectedFeatures():
            codes2 = codes2 + "'" + x['rtu_id'] + "',"
        codes2 = codes2[:-1] + ']'

        query = "SELECT n_by_n_relation('com_link_rtu','colin_id','rtu_id',ARRAY " + codes1 + ", ARRAY "+ codes2 + ")"
        cursor.execute(query)
        self.conn.commit()
        iface.messageBar().pushMessage("Info", "روابط بین جدول های لینک مخابرانی و پایانه راه دور برقرار شد",level = Qgis.Info, duration = 5) 

    def com_stat_link(self):
        self.run()
        cursor = self.conn.cursor()
        tbl1 = self.findLayer('public','com_stat')
        tbl2 = self.findLayer('public','com_link')
        if len(tbl1.selectedFeatures()) == 0 or len(tbl2.selectedFeatures()) == 0:
            iface.messageBar().pushMessage("Warning", "از هر دو جدول باید رکوردهایی انتخاب شده باشند",level = Qgis.Warning, duration = 5) 
            return

        codes1 = '['
        for x in tbl1.selectedFeatures():
            codes1 = codes1 + "'" + x['comst_id'] + "',"
        codes1 = codes1[:-1] + ']'
        codes2 = '['
        for x in tbl2.selectedFeatures():
            codes2 = codes2 + "'" + x['colin_id'] + "',"
        codes2 = codes2[:-1] + ']'

        query = "SELECT n_by_n_relation('com_stat_com_link','comst_id','colin_id',ARRAY " + codes1 + ", ARRAY "+ codes2 + ")"
        cursor.execute(query)
        self.conn.commit()
        iface.messageBar().pushMessage("Info", "روابط بین جدول های ایستگاه مخابراتی و اسکادا و لینک مخابراتی برقرار شد",level = Qgis.Info, duration = 5) 

    def com_stat_tel_center(self):
        self.run()
        cursor = self.conn.cursor()
        tbl1 = self.findLayer('public','com_stat')
        tbl2 = self.findLayer('public','tel_center')

        if len(tbl1.selectedFeatures()) == 0 or len(tbl2.selectedFeatures()) == 0:
            iface.messageBar().pushMessage("Warning", "از هر دو جدول باید رکوردهایی انتخاب شده باشند",level = Qgis.Warning, duration = 5) 
            return

        codes1 = '['
        for x in tbl1.selectedFeatures():
            codes1 = codes1 + "'" + x['comst_id'] + "',"
        codes1 = codes1[:-1] + ']'
        codes2 = '['
        for x in tbl2.selectedFeatures():
            codes2 = codes2 + "'" + x['colin_id'] + "',"
        codes2 = codes2[:-1] + ']'

        query = "SELECT n_by_n_relation('com_stat_tel_center','comst_id','telcen_id',ARRAY " + codes1 + ", ARRAY "+ codes2 + ")"
        cursor.execute(query)
        self.conn.commit()
        iface.messageBar().pushMessage("Info", "روابط بین جدول های ایستگاه مخابراتی و اسکادا و مرکز تلفن برقرار شد",level = Qgis.Info, duration = 5) 

    def substat_circuit(self):
        self.run()
        cursor = self.conn.cursor()
        tbl1 = self.findLayer('public','circuit')
        tbl2 = self.findLayer('public','substat')
        if len(tbl1.selectedFeatures()) == 0 or len(tbl2.selectedFeatures()) == 0:
            iface.messageBar().pushMessage("Warning", "از هر دو جدول باید رکوردهایی انتخاب شده باشند",level = Qgis.Warning, duration = 5) 
            return

        codes1 = '['
        for x in tbl1.selectedFeatures():
            codes1 = codes1 + "'" + x['circt_id'] + "',"
        codes1 = codes1[:-1] + ']'
        codes2 = '['
        for x in tbl2.selectedFeatures():
            codes2 = codes2 + "'" + x['subst_code'] + "',"
        codes2 = codes2[:-1] + ']'

        query = "SELECT n_by_n_relation('circuit_substation','circt_id','subst_code',ARRAY " + codes1 + ", ARRAY "+ codes2 + ")"
        cursor.execute(query)
        self.conn.commit()
        iface.messageBar().pushMessage("Info", "روابط بین جدول های مدار و ابستگاه انتقال و فوق توزیع برقرار شد",level = Qgis.Info, duration = 5) 
    
    def findLayer(self,schema_name,layer_name):
        layers = QgsProject.instance().mapLayers()
        for layer_id, layer in layers.items():
            if '"'+schema_name+'"."'+layer_name+'"' in layer.source():
                return layer
                     
    def run(self):
        usePlugin = UsePlugin()

        if not usePlugin.checkAll():
            return

        dBConnection = DBConnection(
            usePlugin.projVals['host'],
            usePlugin.projVals['port'],
            usePlugin.projVals['dbname'])

        self.dbconn = dBConnection
        self.conn = self.dbconn.getConn()
