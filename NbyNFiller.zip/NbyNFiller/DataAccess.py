import sys, os, os.path
import datetime, time
import logging
import configparser
from typing import TYPE_CHECKING
import psycopg2, psycopg2.extras
from psycopg2 import sql
from .mylib import *
from .rassam import DBConnection, UsePlugin
import re
#========================================================

class DataAccess:

    usePlugin = UsePlugin()
    dBConnection = None


    # Get a connection to the database.
    def getConn(self):
        self.usePlugin.checkProjVariables()
        try:
            self.dBConnection = DBConnection(self.usePlugin.getValue('db_host'), '5432', 'electricity')
            conn = self.dBConnection.getConn()
            conn.autocommit = True
            return conn
        except Exception as e:
            logging.error(e)
            return False


    def getFaNameOfCol(self, name):
        try:
            cur = self.getConn().cursor()
            cur.execute("""
                    SELECT columnname_en2fa(%s);
                """, (name,))
            data = cur.fetchone()
            return data[0]
        except Exception as e:
            logging.error(e)
            return False


    def getTableName_Tr(self,tableName):
        try:
            cur = self.getConn().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = """SELECT table_fa FROM translate_tables where table_en = \'{}\';""".format(tableName)
            cur.execute(query)
            fa_table_name = cur.fetchone()
            return fa_table_name['table_fa']
        except Exception as e:
            logging.error(e)
            return False
        
        