import sys, os, os.path
import datetime, time
from PyQt5 import QtWidgets, QtGui, uic, QtCore
import resources, gui
import mylib
import logging
import pandas as pd
from DataAccess import DataAccess





print(mylib.is_number(3))
print(mylib.is_number('3'))
print(mylib.is_number(''))
print(mylib.is_number('dasf'))
print(mylib.is_number('-3.5'))
print(mylib.is_number(None))


