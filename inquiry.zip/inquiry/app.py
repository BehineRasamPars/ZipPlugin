import sys, os, os.path
from .mylib import *
sys.path.insert(1, getAppDir() + '/packages')
import datetime, time
from typing import TYPE_CHECKING
from PyQt5 import QtWidgets, QtGui, uic, QtCore
from qgis.core import QgsProject
from qgis.PyQt.QtWidgets import QAction, QFileDialog
from qgis.utils import iface
from psycopg2.sql import NULL
from .resources import *
from .gui_add_new import *
from .gui_inquiry import *
from .gui_workflow import *
from .DataAccess import DataAccess
import jdatetime
import xlwt
#========================================================

class Inquiry_GUI(QtWidgets.QMainWindow):

    dataAccess = None
    data = None
    pathList = []
    currTable = ''
    winAddNew = QtWidgets.QDialog()
    winWorkflow = QtWidgets.QDialog()
    currSmid = 0
    currUser = None
    currGroups = None


    def __init__(self):
        super().__init__()
        self.dataAccess = DataAccess()
        self.currUser = self.dataAccess.conf['DB_user']
        self.currGroups = self.dataAccess.getUserGroups(self.currUser)
        self.initUI()

    def initUI(self):

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setFixedSize(self.size())
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app.png'));

        self.statusLabel = QtWidgets.QLabel('')
        self.statusLabel.setAlignment(QtCore.Qt.AlignRight)
        self.ui.statusbar.addWidget(self.statusLabel)

        self.ui.username.setText(self.currUser)
        self.ui.groupNames.setText(listToStr(self.currGroups))
        self.ui.newRecord.clicked.connect(self.newRecord)
        self.ui.refresh.clicked.connect(self.updateWindow)
        self.ui.refresh2.clicked.connect(self.updateWindow)
        self.ui.inqList.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        # self.ui.inqList.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch);
        # self.ui.inqList2.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch);
        self.ui.inqList2.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.ui.inqList.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.ui.inqList2.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.ui.excelOut.clicked.connect(self.excelOutFun)

        self.ui.inqList.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.ui.inqList.customContextMenuRequested.connect(self.generateMenu)
        self.ui.inqList.viewport().installEventFilter(self)

        self.ui.inqList2.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.ui.inqList2.customContextMenuRequested.connect(self.generateMenu2)
        self.ui.inqList2.viewport().installEventFilter(self)

        self.show()
        self.updateWindow()

    def newRecord(self):
        self.ui_newr = Ui_NewRecord()
        self.ui_newr.setupUi(self.winAddNew)
        self.ui_newr.submit.clicked.connect(self.newRecordSubmit)
        self.ui_newr.addCoord.clicked.connect(self.newCoord)
        self.ui_newr.getGeoFromMap.clicked.connect(self.getGeoFromMap)
        self.winAddNew.show()
        self.ui_newr.coords.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)

    def updateWindow(self):
        self.msgUser('wait')

        inqList = self.dataAccess.getInquiryList([self.currUser] + self.currGroups)
        self.ui.inqList.setRowCount(len(inqList))
        for index, item in enumerate(inqList):
            if item['owner'] == self.currUser:
                owner = 'شما'
            else:
                owner = item['owner']
            self.ui.inqList.setItem(index, 0, QtWidgets.QTableWidgetItem(str(item['smid'])))
            date_created = jdatetime.date.fromgregorian(date=item['date_created']).strftime("%d/%m/%Y")
            self.ui.inqList.setItem(index, 1, QtWidgets.QTableWidgetItem(date_created))
            self.ui.inqList.setItem(index, 2, QtWidgets.QTableWidgetItem(item['letter_number']))
            self.ui.inqList.setItem(index, 3, QtWidgets.QTableWidgetItem(owner))
            self.ui.inqList.setItem(index, 4, QtWidgets.QTableWidgetItem(str(item['name'])))
            self.ui.inqList.setItem(index, 5, QtWidgets.QTableWidgetItem(str(item['waiting'])))
            self.ui.inqList.setItem(index, 6, QtWidgets.QTableWidgetItem(str(item['yes'])))
            self.ui.inqList.setItem(index, 7, QtWidgets.QTableWidgetItem(str(item['no'])))
        self.ui.inqList.resizeColumnsToContents()
        header = self.ui.inqList.horizontalHeader()     
        header.setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(4, QtWidgets.QHeaderView.Stretch)

        inqList = self.dataAccess.getInquiryListArchive()
        self.ui.inqList2.setRowCount(len(inqList))
        for index, item in enumerate(inqList):
            if item['date_created']:
                date_created = jdatetime.date.fromgregorian(date=item['date_created']).strftime("%d/%m/%Y")
            else:
                date_created = item['date']
            self.ui.inqList2.setItem(index, 0, QtWidgets.QTableWidgetItem(str(item['smid'])))
            if item['no'] > 0:
                status = 'رد شده'
            else:
                status = 'تایید شده'
            if not item['owner']:
                status = '-'
            self.ui.inqList2.setItem(index, 1, QtWidgets.QTableWidgetItem(status))
            self.ui.inqList2.setItem(index, 2, QtWidgets.QTableWidgetItem(date_created))
            self.ui.inqList2.setItem(index, 3, QtWidgets.QTableWidgetItem(item['letter_number']))
            self.ui.inqList2.setItem(index, 4, QtWidgets.QTableWidgetItem(item['name']))
            self.ui.inqList2.setItem(index, 5, QtWidgets.QTableWidgetItem(item['project_name']))
        self.ui.inqList2.resizeColumnsToContents()
        header = self.ui.inqList2.horizontalHeader()     
        header.setSectionResizeMode(4, QtWidgets.QHeaderView.Stretch)
        header.setSectionResizeMode(5, QtWidgets.QHeaderView.Stretch)
        
        self.msgUser('none')

    def generateMenu(self, pos):
        self.menu.exec_(self.ui.inqList.mapToGlobal(pos))

    def eventFilter(self, source, event):
        if(event.type() == QtCore.QEvent.MouseButtonPress and
            event.buttons() == QtCore.Qt.RightButton and
            source is self.ui.inqList.viewport()):
                item = self.ui.inqList.itemAt(event.pos())
                if not item:
                    self.menu = QtWidgets.QMenu(self)
                    return False
                self.currSmid = self.ui.inqList.item(item.row(), 0).text()
                currOwner = self.ui.inqList.item(item.row(), 3).text() == 'شما'
                if item is not None:
                    self.menu = QtWidgets.QMenu(self)
                    self.menu.addAction('نمایش بر روی نقشه', self.showInMap)
                    self.menu.addAction('مشاهده گردش کار', self.workflow)
                    if not currOwner:
                        self.menu.addAction('تایید استعلام',
                            lambda val1=self.currUser, val2='sent', val3='yes': self.newInqUser(val1, val2, val3))
                        self.menu.addAction('رد استعلام',
                            lambda val1=self.currUser, val2='sent', val3='no': self.newInqUser(val1, val2, val3))
                    if currOwner:
                        self.menu.addAction('حذف', self.delete)
                        roleMenu = self.menu.addMenu('ارسال به')
                        roleMenu2 = roleMenu.addMenu('گروه')
                        roleMenu3 = roleMenu.addMenu('کاربر')
                        roleList = self.dataAccess.getAllGroups()
                        for role in roleList:
                            if role not in [self.currUser] + self.currGroups:
                                roleMenu2.addAction(role,
                                    lambda val1=role, val2='sent', val3=None: self.newInqUser(val1, val2, val3))
                        roleList = self.dataAccess.getAllUsers()
                        for role in roleList:
                            if role != self.currUser:
                                roleMenu3.addAction(role,
                                    lambda val1=role, val2='sent', val3=None: self.newInqUser(val1, val2, val3))
        if(event.type() == QtCore.QEvent.MouseButtonPress and
            event.buttons() == QtCore.Qt.RightButton and
            source is self.ui.inqList2.viewport()):
                item = self.ui.inqList2.itemAt(event.pos())
                self.currSmid = self.ui.inqList2.item(item.row(), 0).text()
                item = self.ui.inqList2.itemAt(event.pos())
                if not item:
                    self.menu = QtWidgets.QMenu(self)
                    return False
                self.menu = QtWidgets.QMenu(self)
                self.menu.addAction('نمایش بر روی نقشه', self.showInMap)
                self.menu.addAction('مشاهده گردش کار', self.workflow)
        return super(Inquiry_GUI, self).eventFilter(source, event)

    def generateMenu2(self, pos):
        self.menu.exec_(self.ui.inqList2.mapToGlobal(pos))
    
    def msgUser(self, type, msg = None): # Send a message to the user. 
        self.statusLabel.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.statusLabel.setText('لطفا صبر کنید ...')
            self.statusLabel.setStyleSheet('color: rgb(60, 60, 60)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()

    def checkCoords(self, points):
        selected_type = self.ui_newr.geomType_CMB.currentIndex()
        print(selected_type)
        print(len(points))
        if selected_type == 0 or len(points) == 0:
            return False
        elif selected_type == 3 and len(points) != 1:
            return False
        elif selected_type == 2 and len(points) < 2:
            return False
        elif selected_type == 1 and len(points) < 3:
            return False
        return True     

    def newRecordSubmit(self):
        thePoints = []
        try:
            for row in range(self.ui_newr.coords.rowCount()):
                thePoints.append(self.ui_newr.coords.item(row, 0).text() + ' ' + self.ui_newr.coords.item(row, 1).text())
            if selected_type == 1:
                thePoints.append(self.ui_newr.coords.item(0, 0).text() + ' ' + self.ui_newr.coords.item(0, 1).text())
        except:
            pass

        if not self.checkCoords(thePoints):
            self.msgUser('fail')
            return

        pointsStr = listToStr(thePoints)
        info = {}
        selected_type = self.ui_newr.geomType_CMB.currentIndex()     
        
        if selected_type == 1:
            info['geom_fld'] = 'smgeometry'
            info['smgeometry'] = 'POLYGON(({}))'.format(pointsStr)
        elif selected_type == 2:
            info['geom_fld'] = 'smgeometry1'
            info['smgeometry'] = 'LINESTRING({})'.format(pointsStr)
        else:
            info['geom_fld'] = 'smgeometry2'
            info['smgeometry'] = 'POINT({})'.format(pointsStr)

        info['letter_number'] = self.ui_newr.number.text()
        info['date'] = ''
        info['project_name'] = self.ui_newr.project.text()
        info['name'] = self.ui_newr.name.text()
        info['address'] = self.ui_newr.addr.toPlainText()
        info['phone'] = self.ui_newr.phone.text()
        info['province'] = self.ui_newr.province.text()
        info['natcode'] = self.ui_newr.natcode.text()
        info['status'] = 'درج شده'
        info['inquiry_response'] = 'منتظر پاسخ'

        if not info['letter_number']:
            self.msgUser('fail')
            return
        
        res1 = self.dataAccess.addNewInq(info)
        if res1:
            res2 = self.dataAccess.newInqUser(res1, self.currUser, 'owner', None)
            res3 = self.dataAccess.newInqWorkflow(res1, 'استعلام ایجاد شده توسط {}'.format(self.currUser))
        if res1 and res2 and res3:
            self.msgUser('success')
            self.updateWindow()
            self.winAddNew.close()
        else:
            self.msgUser('fail')

    def editRecordSubmit(self):
        thePoints = []
        try:
            for row in range(self.ui_newr.coords.rowCount()):
                thePoints.append(self.ui_newr.coords.item(row, 0).text() + ' ' + self.ui_newr.coords.item(row, 1).text())
            thePoints.append(self.ui_newr.coords.item(0, 0).text() + ' ' + self.ui_newr.coords.item(0, 1).text())
        except:
            pass
        pointsStr = listToStr(thePoints)
        info = {}
        info['smgeometry'] = 'SRID=32639; LINESTRING({})'.format(pointsStr)
        info['letter_number'] = self.ui_newr.number.text()
        info['date'] = ''
        info['project_name'] = self.ui_newr.project.text()
        info['name'] = self.ui_newr.name.text()
        info['address'] = self.ui_newr.addr.text()
        info['phone'] = self.ui_newr.phone.text()
        info['province'] = self.ui_newr.province.text()
        info['natcode'] = self.ui_newr.natcode.text()
        info['status'] = 'درج شده'
        info['inquiry_response'] = 'منتظر پاسخ'
        info['smid'] = self.currSmid
        if not info['letter_number']:
            self.msgUser('fail')
            return
        if self.dataAccess.editInq(info):
            self.msgUser('success')
            self.updateWindow()
            self.winAddNew.close()
        else:
            self.msgUser('fail')

    def newCoord(self, x = None, y = None):
        if x == False and y == None:
            x = None
        if not x and x != 0:
            x = self.ui_newr.addX.text()
        if not y and y != 0:
            y = self.ui_newr.addY.text()
        if not is_number(x):
            x = 0
        if not is_number(y):
            y = 0
        rowPosition = self.ui_newr.coords.rowCount()
        self.ui_newr.coords.insertRow(rowPosition)
        self.ui_newr.coords.setItem(rowPosition, 0, QtWidgets.QTableWidgetItem(str(float(x))))
        self.ui_newr.coords.setItem(rowPosition, 1, QtWidgets.QTableWidgetItem(str(float(y))))

    def delete(self):
        smid = self.ui.inqList.item(self.ui.inqList.currentRow(), 0).text()
        if self.dataAccess.delInq(smid):
            self.msgUser('success')
            self.updateWindow()
        else:
            self.msgUser('fail')

    def get_inq_layer(self, smid):
        cur = self.dataAccess.getConnElect().cursor()
        cur.execute("select st_geometrytype(coalesce(smgeometry,smgeometry1,smgeometry2)) from frontage_inquiry where smid = " + str(smid))
        layer_type = cur.fetchone()[0]
        if layer_type == 'ST_Polygon':
            fld = '(smgeometry)'
        elif layer_type == 'ST_Point':
            fld = '(smgeometry2)'
        else:
            fld = '(smgeometry1)'
        
        print(smid)
        print(layer_type)
        print(fld)

        layers = QgsProject.instance().mapLayers()
        for layer_id, layer in layers.items():
            source = layer.source()
            if 'frontage_inquiry' in source and fld in source:
                return layer

    def showInMap(self):
        layer = self.get_inq_layer(self.currSmid)
        print(layer.source())
        if layer:
            layer.select([int(self.currSmid)])
            iface.setActiveLayer(layer)
            iface.actionZoomToSelected().trigger()

    def workflow(self):
        self.ui_workflow = Ui_workflow()
        self.ui_workflow.setupUi(self.winWorkflow)
        self.winWorkflow.show()
        data = self.dataAccess.getInqWorkflow(self.currSmid)
        self.ui_workflow.table.setRowCount(len(data))
        for index, item in enumerate(data):
            theTime = jdatetime.datetime.fromgregorian(datetime=item['created_at']).strftime("%d/%m/%Y %H:%M:%S")
            self.ui_workflow.table.setItem(index, 0, QtWidgets.QTableWidgetItem(theTime))
            self.ui_workflow.table.setItem(index, 1, QtWidgets.QTableWidgetItem(item['msg']))
        self.ui_workflow.table.resizeColumnsToContents()

    def newInqUser(self, roleName, note1, note2):
        if note1 == 'sent' and note2 == None:
            self.dataAccess.newInqWorkflow(self.currSmid, 'ارسال شده به {}'.format(roleName))
        elif note1 == 'sent' and note2 == 'yes':
            self.dataAccess.newInqWorkflow(self.currSmid, 'تایید شده توسط {}'.format(roleName))
        elif note1 == 'sent' and note2 == 'no':
            self.dataAccess.newInqWorkflow(self.currSmid, 'رد شده توسط {}'.format(roleName))
        if note1 == 'sent' and note2 in ['yes', 'no']:
            inqRoles = self.dataAccess.getInqSentRoles(self.currSmid)
            userRoles = [self.currUser] + self.currGroups
            commonRole = list(set(inqRoles).intersection(userRoles))
            roleName = commonRole[0]
        res1 = self.dataAccess.newInqUser(self.currSmid, roleName, note1, note2)
        if res1:
            self.msgUser('success')
            self.updateWindow()
        else:
            self.msgUser('fail')

    def excelOutFun(self):

        filePath = QFileDialog.getSaveFileName(self, 'Save File', '', 'Excel (*.xls)')[0]

        self.msgUser('wait')

        xl = xlwt.Workbook()
        xl_sheet = xl.add_sheet("Sheet1", cell_overwrite_ok=True)
        xl_sheet.cols_right_to_left = True

        for column in range(self.ui.inqList2.columnCount()):
            text = self.ui.inqList2.horizontalHeaderItem(column).text()
            xl_sheet.write(0, column, text)
        for row in range(self.ui.inqList2.rowCount()):
            for column in range(self.ui.inqList2.columnCount()):
                text = self.ui.inqList2.item(row, column).text()
                xl_sheet.write(row + 1, column, text)

        xl.save(filePath)

        self.msgUser('none')
        msgBox = QtWidgets.QMessageBox()
        msg = "خروجی اکسل ذخیره گردید"
        msgBox.setText(msg)
        msgBox.setWindowTitle("موفقیت")
        msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
        msgBox.exec_()

    def getGeoFromMap(self):
        self.ui_newr.coords.setRowCount(0)
        #try:
        layer = iface.layerTreeView().currentLayer()
        features = layer.selectedFeatures()
        geom = features[0].geometry()
        if layer.geometryType() == 0:
            points = geom.asPoint()
            self.newCoord(points.x(), points.y())
        elif layer.geometryType() == 1:
            for point in geom.asMultiPolyline():
                for a_p in point:
                    self.newCoord(a_p.x(), a_p.y())
        elif layer.geometryType() == 2:
            for point in geom.asPolygon():
                for a_p in point:
                    self.newCoord(a_p.x(), a_p.y())
        self.ui_newr.geomType_CMB.setCurrentIndex(3-layer.geometryType())    
