import logging
import configparser
import psycopg2, psycopg2.extras
from psycopg2 import sql
from .mylib import listToStr , getAppDir
#========================================================

class DataAccess:

    conf = {}
    dbOk = False

    def __init__(self):
        self.updateConf()
        self.prepareDB()

    def getConnElect(self):  # Get a connection to the database.
        try:
            print(self.conf)
            conn = psycopg2.connect(user = self.conf['DB_user'],
                            password = self.conf['DB_pass'],
                            host = self.conf['DB_host'],
                            port = self.conf['DB_port'],
                            dbname = self.conf['main_db'])
            conn.autocommit = True

            return conn
        except Exception as e:
            print('miad into')
            logging.error(e)
            return False

    def setConf(self):

        self.conf['mainPath'] = getAppDir()
        self.conf['confFilePath'] = self.conf['mainPath'] + '\\main.conf'
        self.conf['logPath'] = self.conf['mainPath'] + '\\main.log'

        confFile = configparser.ConfigParser()
        confFile.read(self.conf['confFilePath'])
        self.conf['fileLogging'] = confFile.getboolean('Main', 'file_logging')
        self.conf['repAddr'] = confFile['Main']['rep_addr']
        self.conf['repPort'] = confFile['Main']['rep_port']
        self.conf['DB_host'] = confFile['DB']['host']
        self.conf['DB_port'] = confFile['DB']['port']
        self.conf['DB_user'] = confFile['DB']['user']
        self.conf['DB_pass'] = confFile['DB']['pass']
        self.conf['main_db'] = confFile['DB']['main_db']

    def updateConf(self):

        self.setConf()

        # File logging:
        if self.conf['fileLogging']:
            logging.basicConfig(filename=self.conf['logPath'],
                format='%(asctime)s | %(levelname)s | %(message)s', level=logging.INFO)
        else:
            logging.disable()
  
    def prepareDB(self): # Prepare the database.
        # Return True if success, False otherwise.
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                    REVOKE ALL ON SCHEMA
                        public, logs, map, attachments
                    FROM
                        PUBLIC;
                    GRANT USAGE ON SCHEMA
                        public, logs, map, attachments
                    TO
                        PUBLIC;
                """)
            self.dbOk = True
        except Exception as e:
            logging.error(e)
            self.dbOk = False
        return self.dbOk

    def getAllGroups(self):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                    SELECT
                        groname
                    FROM
                        pg_catalog.pg_group
                    WHERE
                        groname NOT LIKE 'pg_%'
                    ORDER BY
                        groname
                """)
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            logging.error(e)
            return False
    
    def addGroup(self, groupName): # Create and add a new group.
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                CREATE GROUP {}
                """).format(sql.Identifier(groupName))
            cur.execute(query)
            self.grantDefinedToRole(cur, groupName)
            return True
        except Exception as e:
            logging.error(e)
            return False

    def delRole(self, roleName): # Delete a role (user/group).
        self.addRolePlugins(roleName, [])
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA
                        public, logs, map, attachments
                    FROM
                        {roleName};
                    REVOKE ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA
                        public, logs, map, attachments
                    FROM
                        {roleName};
                    REVOKE ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA
                        public, logs, map, attachments
                    FROM
                        {roleName};
                    DROP ROLE {roleName};
                    DELETE FROM logs.user_info WHERE username = %s;
                """).format(roleName = sql.Identifier(roleName))
            cur.execute(query, (roleName,))
            return True
        except Exception as e:
            logging.error(e)
            print(e)
            return False

    def renameRole(self, oldName, newName):
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    ALTER ROLE {} RENAME TO {}
                """).format(sql.Identifier(oldName), sql.Identifier(newName))
            cur.execute(query)
            return True
        except Exception as e:
            logging.error(e)
            return False
    
    def getUsers(self, groupName = None): # Get list of users. Pass groupName in case want group's users.
        try:
            if not groupName:
                cur = self.getConnElect().cursor()
                cur.execute("""
                        SELECT
                            usename
                        FROM
                            pg_catalog.pg_user
                        ORDER BY
                            usename
                    """)
                rows = [r[0] for r in cur.fetchall()]
                return rows
            else:
                cur = self.getConnElect().cursor()
                cur.execute("""
                        SELECT
                            r.rolname as username, r1.rolname as "role"
                        FROM
                            pg_catalog.pg_roles r
                        JOIN pg_catalog.pg_auth_members m ON (m.member = r.oid)
                        JOIN pg_roles r1 ON (m.roleid = r1.oid)
                        WHERE
                            r1.rolname = %s
                        ORDER BY
                            1;
                    """, (groupName,))
                rows = [r[0] for r in cur.fetchall()]
                return rows
        except Exception as e:
            logging.error(e)
            return False

    def addToGroup(self, user, group): # Add a user to a group (add any role to any role).
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    GRANT {} TO {}
                """).format(sql.Identifier(group), sql.Identifier(user))
            cur.execute(query)
            return True
        except Exception as e:
            logging.error(e)
            return False

    def delFromGroup(self, user, group): # Delete a user from a group (delete any role from any role).
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    REVOKE {} FROM {}
                """).format(sql.Identifier(group), sql.Identifier(user))
            cur.execute(query)
            return True
        except Exception as e:
            logging.error(e)
            return False

    def setRolePass(self, role, password): # Set a password for a role (user).
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    ALTER ROLE {}
                        PASSWORD %s
                """).format(sql.Identifier(role))
            cur.execute(query, (password,))
            return True
        except Exception as e:
            logging.error(e)
            return False

    def addUser(self, userName, password, validUntil, usergroup, description): # Add a new user.
        try: 
            cur = self.getConnElect().cursor()
            if not validUntil:
                query = sql.SQL("""
                        CREATE USER
                            {}
                        PASSWORD %s
                    """).format(sql.Identifier(userName))
                cur.execute(query, (password,))
            else:
                query = sql.SQL("""
                        CREATE USER
                            {}
                        PASSWORD %s
                        VALID UNTIL %s
                    """).format(sql.Identifier(userName))
                cur.execute(query, (password, validUntil.strftime('%Y-%m-%dT%H:%M:%S+00:00'),))
            self.grantDefinedToRole(cur, userName)
            self.addToGroup(userName, usergroup)
            self.changeUserDesc(userName, description)
            return True
        except:
            return False
    
    def grantDefinedToRole(self, cur, roleName): # Grant the predefined privileges to a role.
        query = sql.SQL("""
                GRANT SELECT ON ALL TABLES IN SCHEMA public, map, attachments TO {roleName};
                GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA logs TO {roleName};
                REVOKE ALL ON TABLE logs.brp_settings FROM {roleName};
                GRANT SELECT, UPDATE ON TABLE logs.brp_settings TO {roleName};
                GRANT analysis TO {roleName};
            """).format(roleName=sql.Identifier(roleName))
        cur.execute(query)
        if self.conf['main_db'] == 'electricity_red':
            query = sql.SQL("""
                GRANT ALL ON ALL SEQUENCES IN SCHEMA public to {roleName};
                GRANT SELECT, UPDATE, DELETE, INSERT ON TABLE
                    public.frontage_inquiry, public.inq_user, public.inq_workflow
                    TO {roleName};
            """).format(roleName=sql.Identifier(roleName))
            cur.execute(query)
        return True

    def getRoleTables(self, roleName): # Get all the tables along with the privileges for the specified user.
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT
                    tables.table_schema as schema,
                    tables.table_name AS table,
                    CASE tables.table_schema
                        WHEN 'public' THEN 'GIS'
                        ELSE tables.table_schema
                    END as schema2,
                    smregister.smtablename AS table2,
                    string_agg(privilege_type, ', ') LIKE '%%SELECT%%' AS SELECT,
                    string_agg(privilege_type, ', ') LIKE '%%INSERT%%' AS INSERT,
                    string_agg(privilege_type, ', ') LIKE '%%UPDATE%%' AS UPDATE,
                    string_agg(privilege_type, ', ') LIKE '%%DELETE%%' AS DELETE
                FROM
                    information_schema.tables
                INNER JOIN
                    public.smregister
                ON
                    information_schema.tables.table_name = public.smregister.smdatasetname
                LEFT JOIN
                    (SELECT * FROM information_schema.role_table_grants WHERE grantee = %s) AS role_table_grants
                ON
                    tables.table_schema = role_table_grants.table_schema AND tables.table_name = role_table_grants.table_name
                WHERE
                    tables.table_schema IN ('public', 'map', 'attachments')
                GROUP BY
                    tables.table_schema, tables.table_name, smregister.smtablename
                ORDER BY schema2
                """, (roleName,))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def grantRoleToTable(self, schema, table, role, select, insert, update, delete): # Grant a table privilege to a role (user/group).

        privileges = []
        if select:
            privileges.append('SELECT')
        if insert:
            privileges.append('INSERT')
        if update:
            privileges.append('UPDATE')
        if delete:
            privileges.append('DELETE')
        privileges = listToStr(privileges)

        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    REVOKE ALL ON TABLE {} FROM {};
                """).format(sql.Identifier(schema, table),
                            sql.Identifier(role))
            cur.execute(query)
            if privileges:
                query = sql.Composed([
                    sql.SQL("GRANT " + privileges),
                    sql.SQL(" ON TABLE {} TO {}").format(sql.Identifier(schema, table), sql.Identifier(role))
                ])
                cur.execute(query)
            return True
        except Exception as e:
            logging.error(e)
            return False
    
    def getRolePlugins(self, roleName): # Get list of plugins that a role (user/group) can access to.
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                    SELECT
                        plugin
                    FROM
                        public.plugin_role
                    WHERE role = %s
                """, (roleName,))
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getRoleApp(self, roleName): # Get list of app access for a role (user/group).
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                    SELECT
                        name
                    FROM
                        app_access
                    INNER JOIN
                    	app_role ON app_access.access_id = app_role.app_access_id
                    WHERE role = %s
                """, (roleName,))
            rows = [r[0] for r in cur.fetchall()]
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getAppAccessList(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT
                        access_id, name
                    FROM
                        app_access
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False
  
    def addRolePlugins(self, roleName, plugins): # Set a list of plugins for a role (user/group).
        # Pass empty list if want to delete all plugins.
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                    DELETE FROM
                        public.plugin_role
                    WHERE role = %s
                """, ([roleName]))
            for plugin in plugins:
                cur.execute("""
                    INSERT INTO public.plugin_role
                        ("role", "plugin")
                    VALUES
                        (%s, %s)
                """, ([roleName, plugin]))
            return True
        except Exception as e:
            logging.error(e)
            return False

    def addRoleApp(self, roleName, access_ids):
        try:
            cur = self.getConnElect().cursor()
            cur.execute("""
                    DELETE FROM
                        public.app_role
                    WHERE role = %s
                """, ([roleName]))
            for access_id in access_ids:
                cur.execute("""
                    INSERT INTO public.app_role
                        ("role", "app_access_id")
                    VALUES
                        (%s, %s)
                """, ([roleName, access_id]))
            return True
        except Exception as e:
            logging.error(e)
            return False

    def changeUserDesc(self, userName, desc):
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    INSERT INTO logs.user_info (username, description)
                    VALUES (%s, %s)
                    ON CONFLICT (username) DO UPDATE SET description = EXCLUDED.description
                """)
            cur.execute(query, (userName, desc,))
            return True
        except Exception as e:
            logging.error(e)
            return False

    def getUserInfo(self, userName):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            query = sql.SQL("""
                    SELECT * FROM logs.user_info WHERE username = %s
                """)
            cur.execute(query, (userName,))
            rows = cur.fetchone()
            return rows
        except Exception as e:
            logging.error(e)
            return False