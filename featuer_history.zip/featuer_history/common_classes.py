# -*- coding: utf-8 -*-

import psycopg2
from qgis.core import QgsDataSourceUri, QgsCredentials, QgsProject, QgsExpressionContextUtils

    
class DBConnection:

    loginData = QgsDataSourceUri()
    conn = None

    def __init__(self, host, port, dbName):
        self.loginData.setConnection(host, port, dbName, None, None, 1)

    def __del__(self):
        self.closeConn()

    def getConnIfValid(self, username, password):
        try:
            conn = psycopg2.connect(user = username,
                                  password = password,
                                  host = self.loginData.host(),
                                  port = self.loginData.port(),
                                  dbname = self.loginData.database())
            return conn
        except:
            return False

    # return connection if success; else None.
    def getConn(self):
        if (not self.conn):
            connInfo = self.loginData.connectionInfo()
            inUser = None
            inPass = None
            success = True
            while (success):
                (success, inUser, inPass) = QgsCredentials.instance().get(connInfo, inUser, inPass)
                conn = self.getConnIfValid(inUser, inPass)
                if (conn):
                    QgsCredentials.instance().put(connInfo, inUser, inPass)
                    self.validData = True
                    self.loginData.setUsername(inUser)
                    self.loginData.setPassword(inPass)
                    self.conn = conn
                    break
        return self.conn

    # return username if a valid one entered. None otherwise.
    def getUsername(self):
        return self.loginData.username()

    def getHost(self):
        return self.loginData.host()

    def closeConn(self):
        if (self.conn):
            self.conn.close()
            self.conn = None
            
    def getPerNameOfTable(self, engName):
        cursor = self.getConn().cursor()
        query = ('SELECT smtablename FROM public.smregister where smdatasetname = \'%s\'')%engName
        cursor.execute(query)
        for row in cursor.fetchall():
            smtablename = row[0]
        return smtablename
    
    def getEngNameOfTable(self, perName):
        cursor = self.getConn().cursor()
        query = ('SELECT smdatasetname FROM public.smregister where smtablename = \'%s\'')%perName
        cursor.execute(query)
        for row in cursor.fetchall():
            smdatasetname = row[0]
        return smdatasetname


# Get host from project variables:
def getDBConnection():
    project = QgsProject.instance()
    host = QgsExpressionContextUtils.projectScope(project).variable('host')
    if host:
        conn = DBConnection(host, '5432', 'electricity')
        return conn
    else:
        return False