<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it" sourcelanguage="en">
<context>
    <name>AttributePainterForm</name>
    <message>
        <location filename="../ui_attributepainter.ui" line="26"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="32"/>
        <source>Pick source feature</source>
        <translation>Indica la feature sorgente</translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="42"/>
        <source>Select all attributes</source>
        <translation>Seleziona tutti gli attributi</translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="75"/>
        <source>Reset source</source>
        <translation>Risistema la feature sorgente</translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="84"/>
        <source>Apply  to selection</source>
        <translation>Applica alle feature selezionate</translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="91"/>
        <source>Pick to Apply</source>
        <translation>Indica ed applica</translation>
    </message>
</context>
</TS>
