<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>AttributePainterForm</name>
    <message>
        <location filename="../ui_attributepainter.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="32"/>
        <source>Pick source feature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="42"/>
        <source>Select all attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="75"/>
        <source>Reset source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="84"/>
        <source>Apply  to selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_attributepainter.ui" line="91"/>
        <source>Pick to Apply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
