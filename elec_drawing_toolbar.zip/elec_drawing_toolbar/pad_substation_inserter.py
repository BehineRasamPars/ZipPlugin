from qgis.core import QgsFeature,QgsVectorLayer, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes

from PyQt5.QtWidgets import QMessageBox
from .utils.BRPRect import BRPRect
from .feature_inserter import FeatureInserter
from .insert_substation import SubstationInserter

from math import sin, cos, radians, pi, hypot

class PadSubstationInserter(SubstationInserter):
    LEVELS = 14 # this is the default value for discnt_s to be drawn inversed (default)
    MV_BUSBAR_LEVEL = 0
    CLASS_TYPE = 'pd_mdsub'
    noTrans = 1
    

    def rotate_point(self, point, angle, center_point=(0, 0)):
        """Rotates a point around center_point(origin by default)
        Angle is in degrees.
        Rotation is counter-clockwise
        """
        angle_rad = radians(angle % 360)
        # Shift the point so that center_point becomes the origin
        new_point = (point[0] - center_point[0], point[1] - center_point[1])
        new_point = (new_point[0] * cos(angle_rad) - new_point[1] * sin(angle_rad),
                    new_point[0] * sin(angle_rad) + new_point[1] * cos(angle_rad))
        # Reverse the shifting we have done
        new_point = (new_point[0] + center_point[0], new_point[1] + center_point[1])
        return new_point

    def QgsPointXY2(self, x, y):
        newPoint = self.rotate_point([x,y], self.angle, self.center)
        newPointQgs = QgsPointXY(newPoint[0], newPoint[1])
        return newPointQgs

    def drawCirckBrk(self , x):
        levelY = self.levelY
        self.createMutipleGeomFeature(self.UML, 'circt_brk',[
                                                        self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 0]),
                                                        self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 1]),
                                                        self.QgsPointXY2(x, levelY[self.MV_BUSBAR_LEVEL + 2])
                                                    ],angle=270-self.object_angle , class_type=self.classTypes['circt_brk'])
        self.mbverP.append(self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 0]))
        FeatureInserter(self.canvas, 'Point', 'mv_c_hd', [self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 2])],angle=270-self.object_angle)
        FeatureInserter(self.canvas, 'LineString', self.UML,[ 
                                                        self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 2]),
                                                        self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 3]) 
                                                    ])
        FeatureInserter(self.canvas, 'Point', 'mv_c_hd', [self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 3])],angle=270-self.object_angle)
        
    def drawTransBranch(self,x):
        levelY = self.levelY
        self.drawCirckBrk(x)
        self.createTransFeature(self.UML,self.ULL,'dist_tr',[
                                                        self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 3]),
                                                        self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 4]),
                                                        self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 5])
                                                    ],angle=270-self.object_angle , class_type=self.classTypes['dist_tr']) 
        FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 5])],angle=270-self.object_angle)
        # FeatureInserter(self.canvas, 'LineString', self.ULL, [
        #                                                 self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 4]),
        #                                                 self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 5])
        #                                             ])  # Trans to Board            
        self.createMutipleGeomFeature(self.ULL, 'auto_switch', [
                                                        self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 5]),
                                                        self.QgsPointXY2(x,levelY[self.MV_BUSBAR_LEVEL + 6]),
                                                        self.QgsPointXY2(x, levelY[self.MV_BUSBAR_LEVEL + 7])
                                                    ],angle=270-self.object_angle , class_type=self.classTypes['auto_switch'])
        self.lbverP.append(self.QgsPointXY2(x, levelY[self.MV_BUSBAR_LEVEL + 7]))


    def __init__(self,canvas,bRect,noMvFeeders,noLvFeeders,noLightFeeders,angle,noTrans,isTransRightAligned):
        self.center = [
            (bRect.left + bRect.right) / 2,
            (bRect.top + bRect.bottom) / 2
        ]
        self.angle = self.calculate_angle(angle)
        self.object_angle = self.calculate_object_angle(self.angle)
        self.noMvFeeders = noMvFeeders
        self.noLvFeeders = noLvFeeders
        self.noLightFeeders = noLightFeeders
        self.noTrans = noTrans
        self.isTransRightAligned = isTransRightAligned
        self.mbverP=[]
        self.lbverP=[]
        if not isTransRightAligned:
            # when the switches suppose to be above the mv busbar then it is
            # +2 levels more than the invsered settings (inversed layout is the default in that switches are below to mv busbar)
            self.LEVELS += 2
            self.MV_BUSBAR_LEVEL = 2
            lvBusbarLevel = 9
        else:
            self.MV_BUSBAR_LEVEL = 0
            lvBusbarLevel = 7            

        self.canvas = canvas
        self.width = bRect.getWidth()
        self.height = bRect.getHeight()
        vertical_unit = self.height / self.LEVELS
        
        levelY = []
        for i in range(0,self.LEVELS):
            levelY.append( bRect.top - (i*vertical_unit) )            
        self.levelY = levelY
        self.setPointType()
        

        mvBoardLevel1 = (levelY[self.MV_BUSBAR_LEVEL]+levelY[self.MV_BUSBAR_LEVEL+1])/2
        mvBoardLevel2 = (levelY[self.MV_BUSBAR_LEVEL+1]+levelY[self.MV_BUSBAR_LEVEL+2])/2
        FeatureInserter(self.canvas, 'Polygon', 'mv_s_brd', [self.QgsPointXY2(bRect.left,mvBoardLevel1),self.QgsPointXY2(bRect.right,mvBoardLevel1),self.QgsPointXY2(bRect.right,mvBoardLevel2),self.QgsPointXY2(bRect.left,mvBoardLevel2),self.QgsPointXY2(bRect.left,mvBoardLevel1)])  # mv Board
        # the plus is for trans branch
        if isTransRightAligned:
            switch_x_parts = noMvFeeders + self.noTrans
            switchHSpace =  self.width / switch_x_parts
            # the last + 1 is because python range(1,n) goes till n-1                    
            for i in range(1 , noMvFeeders + self.noTrans + 1):
                switchX = bRect.left + ((i-1) * switchHSpace) + (switchHSpace / 2)
                if i <= noMvFeeders :
                    # Drawing sectioners
                    self.createMutipleGeomFeature(self.UML, 'discnt_s',[
                                                                            self.QgsPointXY2(switchX,levelY[0]),
                                                                            self.QgsPointXY2(switchX,levelY[1]),
                                                                            self.QgsPointXY2(switchX, levelY[2])
                                                                        ],angle=270-self.object_angle,class_type=self.classTypes['discnt_s'])                                                                            
                    FeatureInserter(self.canvas, 'Point', 'mv_c_hd', [self.QgsPointXY2(switchX,levelY[2])],angle=270-self.object_angle)
                    self.mbverP.append(self.QgsPointXY2(switchX,levelY[0]))
                else:
                    if noLvFeeders != 0:
                    # Drawing transformer(s)
                        self.drawTransBranch(switchX)
                    else:
                        self.drawCirckBrk(switchX)
        else:
            switch_x_parts = noMvFeeders
            switchHSpace =  self.width / switch_x_parts
            # the last + 1 is because python range(1,n) goes till n-1                    
            for i in range(1 , noMvFeeders + 1):
                switchX = bRect.left + ((i-1) * switchHSpace) + (switchHSpace / 2)                
                # Drawing sectioners
                self.createMutipleGeomFeature(self.UML, 'discnt_s',[
                                                                        self.QgsPointXY2(switchX,levelY[0]),
                                                                        self.QgsPointXY2(switchX,levelY[1]),
                                                                        self.QgsPointXY2(switchX,levelY[2])
                                                                    ],angle=270-self.object_angle)                                                                            
                FeatureInserter(self.canvas, 'Point', 'mv_c_hd', [self.QgsPointXY2(switchX,levelY[0])],angle=270-self.object_angle,class_type=self.classTypes['discnt_s'])
                self.mbverP.append(self.QgsPointXY2(switchX,levelY[2]))
            if noLvFeeders != 0:
                trans_x_parts = noTrans
                transHSpace =  self.width / trans_x_parts
                for i in range(1 , noTrans + 1):
                    transX = bRect.left + ((i-1) * transHSpace) + (transHSpace / 2)                
                    # Drawing transformer(s)
                    self.drawTransBranch(transX)
            else:
                self.drawCirckBrk(switchX)

        FeatureInserter(self.canvas, 'LineString', 'busbar', [self.QgsPointXY2(bRect.left,levelY[self.MV_BUSBAR_LEVEL]),self.QgsPointXY2(bRect.right,levelY[self.MV_BUSBAR_LEVEL])], need_vertex=True , verPoint=self.mbverP)  # mv busbar
        # the first + 1 is the header of light feeder (above its busrbar and contactor (the first fuse_switch)
        # the second + 1 is because each n fuse_switch create n+1 parts
        if noLvFeeders != 0:
            lvBoardLevel1 = (levelY[lvBusbarLevel] + levelY[lvBusbarLevel+1])/2
            lvBoardLevel2 = (levelY[lvBusbarLevel+1] + levelY[lvBusbarLevel+2])/2
            FeatureInserter(self.canvas, 'Polygon', 'lv_s_brd', [self.QgsPointXY2(bRect.left,lvBoardLevel1),self.QgsPointXY2(bRect.right,lvBoardLevel1),self.QgsPointXY2(bRect.right,lvBoardLevel2),self.QgsPointXY2(bRect.left,lvBoardLevel2),self.QgsPointXY2(bRect.left,lvBoardLevel1)])  # lv Board
            feeder_x_parts = (noLvFeeders)
            feederHSpace =  self.width / feeder_x_parts
            lightX = None
            for i in range(1,noLvFeeders + 1):
                feederX = bRect.left + ((i-1) * feederHSpace) + (feederHSpace / 2)
                fuse_switch_top_line_first_point = self.QgsPointXY2(feederX,levelY[self.MV_BUSBAR_LEVEL + 7])
                fuse_switch_point = self.QgsPointXY2(feederX,levelY[self.MV_BUSBAR_LEVEL + 8])
                fuse_switch_below_line_second_point = self.QgsPointXY2(feederX, levelY[self.MV_BUSBAR_LEVEL + 9])
                
                self.lbverP.append(fuse_switch_top_line_first_point)
                self.createMutipleGeomFeature(self.ULL, 'fuse_switch',[fuse_switch_top_line_first_point,fuse_switch_point,fuse_switch_below_line_second_point],angle=270-self.object_angle , class_type= self.classTypes['fuse_switch'])
                FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(feederX,levelY[self.MV_BUSBAR_LEVEL + 9])],angle=270-self.object_angle)
                if i == 1 and noLightFeeders!=0:
                    lightX = feederX
                    FeatureInserter(self.canvas, 'Point', 'lighting_control_system', [self.QgsPointXY2(feederX, levelY[self.MV_BUSBAR_LEVEL + 9])])
                else:
                    FeatureInserter(self.canvas, 'Point', 'lv_feeder', [self.QgsPointXY2(feederX,levelY[self.MV_BUSBAR_LEVEL + 9])],angle=270-self.object_angle)

            if noLightFeeders != 0:
                self.createMutipleGeomFeature(self.ULL, 'contactor',[self.QgsPointXY2(lightX,levelY[self.MV_BUSBAR_LEVEL + 9]),
                                                                    self.QgsPointXY2(lightX, levelY[self.MV_BUSBAR_LEVEL + 10]),
                                                                    self.QgsPointXY2(lightX, levelY[self.MV_BUSBAR_LEVEL + 11])],angle=270-self.object_angle,class_type= self.classTypes['contactor'])
                if noLightFeeders == 1:
                    FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(lightX, levelY[self.MV_BUSBAR_LEVEL + 11])],angle=270-self.object_angle)

                    self.createMutipleGeomFeature(self.ULL, 'fuse_switch',[self.QgsPointXY2(lightX,levelY[self.MV_BUSBAR_LEVEL + 11]),
                                                                    self.QgsPointXY2(lightX, levelY[self.MV_BUSBAR_LEVEL + 12]),
                                                                    self.QgsPointXY2(lightX, levelY[self.MV_BUSBAR_LEVEL + 13])],angle=270-self.object_angle,class_type= self.classTypes['fuse_switch'])
                    FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(lightX, levelY[self.MV_BUSBAR_LEVEL + 13])],angle=270-self.object_angle)
                    FeatureInserter(self.canvas, 'Point', 'lv_feeder', [self.QgsPointXY2(lightX, levelY[self.MV_BUSBAR_LEVEL + 13])],angle=270-self.object_angle)
                else:
                    # Creating light-busbar
                    lightBusbarWidth = self.calculateLightBusbarWidth(noLightFeeders,feederHSpace)
                    # we want the above drawn contactor to be at the middle of this light busbar
                    FeatureInserter(self.canvas, 'LineString', 'lv_busbar',
                                    [self.QgsPointXY2(lightX - (lightBusbarWidth / 2), levelY[self.MV_BUSBAR_LEVEL + 11]),
                                    self.QgsPointXY2(lightX + (lightBusbarWidth / 2),levelY[self.MV_BUSBAR_LEVEL + 11])])
                    light_feeder_x_parts = (noLightFeeders)
                    lightFeederHSpace = lightBusbarWidth / light_feeder_x_parts

                    for i in range(1,noLightFeeders + 1):
                        lightFeederX = lightX - (lightBusbarWidth / 2) + ((i - 1) * lightFeederHSpace) + (lightFeederHSpace / 2)
                        self.createMutipleGeomFeature(self.ULL, 'fuse_switch', [self.QgsPointXY2(lightFeederX, levelY[self.MV_BUSBAR_LEVEL + 11]),
                                                                        self.QgsPointXY2(lightFeederX, levelY[self.MV_BUSBAR_LEVEL + 12]),
                                                                        self.QgsPointXY2(lightFeederX, levelY[self.MV_BUSBAR_LEVEL + 13])],angle=270-self.object_angle,class_type= self.classTypes['fuse_switch'])
                        FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(lightFeederX, levelY[self.MV_BUSBAR_LEVEL + 13])],angle=270-self.object_angle)
                        FeatureInserter(self.canvas, 'Point', 'lv_feeder', [self.QgsPointXY2(lightFeederX, levelY[self.MV_BUSBAR_LEVEL + 13])],angle=270-self.object_angle)
                        
            FeatureInserter(self.canvas, 'LineString', 'lv_busbar', [self.QgsPointXY2(bRect.left,levelY[lvBusbarLevel]),self.QgsPointXY2(bRect.right,levelY[lvBusbarLevel])],need_vertex=True , verPoint=self.lbverP)  # lv busbar

    def calculate_object_angle(self,angle):
        if 270 - angle < 0:
            angle =  angle - 360
        return angle
    
    def calculate_angle(self , angle):
        return angle%360 
    
    
    def setPointType(self):
        self.classTypes = {'recloser': -1, 'modem': -2, 'hv_switch': -3, 'sectionalizer': -4, 'pt': -5, 'arrow': -6, 'dist_tr': -7, 'contactor': -8,
                           'discnt_s': -9, 'circt_brk': -10, 'current_trans': -11, 'cutout_fuse': -12, 'auto_switch': -13, 'fuse_switch': -14, 'auto_boostr': -15, 'surg_arstr' : -16 , 'ug_lv_line' : -19}
  