import PyQt5
from PyQt5.QtWidgets import QRubberBand
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import Qt, QRectF
from qgis.core import QgsVectorLayer, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes
from qgis.gui import QgsMapTool, QgsMapCanvas, QgsVertexMarker, QgsMapCanvasItem, QgsRubberBand, QgsMapToolEmitPoint


class DrawRectangle(QgsMapTool):
    """QGIS Plugin Implementation."""

    def __init__(self, canvas, layername):
        print("Starting DrawRectangle...", layername)
        self.canvas = canvas
        self.layername = layername
        QgsMapTool.__init__(self, self.canvas)
        print('creating rubberband object')
        self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        print('setting color to red')
        self.rubberBand.setColor(Qt.red)
        self.rubberBand.setWidth(3)
        print('resetting rubber')
        self.reset()
        print("Done initializing.")

    def reset(self):
        self.startPoint = self.endPoint = None
        self.isEmittingPoint = False
        self.rubberBand.reset(True)

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        if self.startPoint is None:
            return
        if not self.isEmittingPoint:
            return
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.showRubber(self.startPoint, point)
        # self.rubberBand.setGeometry([self.startPoint,event])

    def canvasReleaseEvent(self, event):
        # Get the click
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        if self.startPoint is None:
            self.startPoint = point
            self.endPoint = self.startPoint
            self.isEmittingPoint = True
        else:
            self.endPoint = point
            self.isEmittingPoint = False

    def deactivate(self):
        QgsMapTool.deactivate(self)
        self.rubberBand.hide()
        self.deactivated.emit()

    def activate(self):
        QgsMapTool.activate(self)

    def showRubber(self, startPoint, endPoint):
        self.rubberBand.reset(QgsWkbTypes.PolygonGeometry)
        if startPoint.x() == endPoint.x() or startPoint.y() == endPoint.y():
          return

        point1 = QgsPoint(startPoint.x(), startPoint.y())
        point2 = QgsPoint(startPoint.x(), endPoint.y())
        point3 = QgsPoint(endPoint.x(), endPoint.y())
        point4 = QgsPoint(endPoint.x(), startPoint.y())

        self.rubberBand.addPoint(point1, False)
        self.rubberBand.addPoint(point2, False)
        self.rubberBand.addPoint(point3, False)
        self.rubberBand.addPoint(point4, True)  # true to update canvas
        self.rubberBand.show()
