from qgis.core import QgsFeature, QgsVectorLayer, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes

from PyQt5.QtWidgets import QMessageBox
from .utils.BRPRect import BRPRect
from .feature_inserter import FeatureInserter


class SubstationInserter:
    UML = 'ug_mv_line'
    OML = 'oh_mv_line'
    IC = 'internal_cable'
    ULL = 'ug_lv_line'
    OLL = 'oh_lv_line'
    SA = 'surg_arstr'
    ES = 'earth_sys'

    LEVELS = 16
    CLASS_TYPE = 'should be defined in subclass'
    canvas = None
    # if light feeders are more than 1 then we need to create a light busbar and when we
    # create a busbar, it is much more elegant to reduce the busbar size rather than just
    # creating it like 2X of feeder's fuse_switchs horizontal space.
    lightBusbarMarginByPercentage = 0.1

    def createMutipleGeomFeature(self, lineFeature, pointFeature, points, angle=None, class_type=None):
        FeatureInserter(self.canvas, 'LineString', lineFeature, [
                        points[0], points[1]], class_type=class_type)  # 0,1
        FeatureInserter(self.canvas, 'Point', pointFeature, [points[1]], angle)
        FeatureInserter(self.canvas, 'LineString', lineFeature, [
                        points[1], points[2]], class_type=class_type)  # 1,2

    def createTransFeature(self, upperlineFeature, lowerLineFeature, pointFeature, points, angle=None, class_type=None):
        FeatureInserter(self.canvas, 'LineString', upperlineFeature, [
                        points[0], points[1]], class_type=class_type)
        FeatureInserter(self.canvas, 'Point', pointFeature,
                        [points[1]], angle=angle)
        FeatureInserter(self.canvas, 'LineString', lowerLineFeature, [
                        points[1], points[2]], class_type=class_type)
        if self.CLASS_TYPE == 'pl_mdsub':
            FeatureInserter(self.canvas, 'Point', self.CLASS_TYPE, [
                            points[1]], angle=angle + 90)
        else:
            FeatureInserter(self.canvas, 'Point', self.CLASS_TYPE, [
                            points[1]], angle=angle)

    def calculateLightBusbarWidth(self, noLightFeeders, feederHSpace):
        busbarWidth = 0
        # meter, 50 centimeters look pretty and the fuse_switch symbol fit in
        minimumHorizontalSpaceBTWFeeders = 0.4
        while busbarWidth < (minimumHorizontalSpaceBTWFeeders * (noLightFeeders+1)):
            busbarWidth += feederHSpace
        return busbarWidth * (1-self.lightBusbarMarginByPercentage)

    def createEarthFeature(self, lineFeature, pointFeature, points, angle=None):

        FeatureInserter(self.canvas, 'LineString', lineFeature,
                        [points[0], points[1]])  # 0,1
        FeatureInserter(self.canvas, 'LineString', lineFeature,
                        [points[1], points[2]])  # 1,2
