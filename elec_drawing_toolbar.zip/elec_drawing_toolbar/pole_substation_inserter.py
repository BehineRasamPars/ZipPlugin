from qgis.core import QgsPointXY
from PyQt5.QtWidgets import QMessageBox
from .utils.BRPRect import BRPRect
from .feature_inserter import FeatureInserter
from .insert_substation import SubstationInserter
from math import sin, cos, radians, pi, hypot

class PoleSubstationInserter(SubstationInserter):
    LEVELS = 16
    CLASS_TYPE = 'pl_mdsub'

    def rotate_point(self, point, angle, center_point=(0, 0)):
        """Rotates a point around center_point(origin by default)
        Angle is in degrees.
        Rotation is counter-clockwise
        """
        angle_rad = radians(angle % 360)
        # Shift the point so that center_point becomes the origin
        new_point = (point[0] - center_point[0], point[1] - center_point[1])
        new_point = (new_point[0] * cos(angle_rad) - new_point[1] * sin(angle_rad),
                    new_point[0] * sin(angle_rad) + new_point[1] * cos(angle_rad))
        # Reverse the shifting we have done
        new_point = (new_point[0] + center_point[0], new_point[1] + center_point[1])
        return new_point


    def QgsPointXY2(self, x, y):
        newPoint = self.rotate_point([x,y], self.angle, self.center)
        newPointQgs = QgsPointXY(newPoint[0], newPoint[1])
        return newPointQgs

    def __init__(self,canvas,bRect,nofeeders,noLightFeeders,angle,isFeederExist,IsBrdEearthExist):
        self.center = [
            (bRect.left + bRect.right) / 2,
            (bRect.top + bRect.bottom) / 2
        ]
        self.isFeederExist = isFeederExist
        self.IsBrdEearthExist = IsBrdEearthExist
        self.angle = self.calculate_angle(angle)
        self.object_angle = self.calculate_object_angle(self.angle)
        self.canvas = canvas
        self.width = bRect.getWidth()
        self.height = bRect.getHeight()
        vertical_unit = self.height / self.LEVELS
        topMiddle = bRect.getTopMiddle()
        levelPoints = []
        self.lbverP = []
        for i in range(0,self.LEVELS):
            levelPoints.append(QgsPointXY(topMiddle.x(),topMiddle.y()-(i*vertical_unit)))
        levelPoints2 = []
        for i in range(0,self.LEVELS):
            levelPoints2.append(self.QgsPointXY2(topMiddle.x(),topMiddle.y()-(i*vertical_unit)))

        self.setPointType()
        
        
        feeder_x_parts = (nofeeders)
        feederHSpace =  self.width / feeder_x_parts
        surg_arstrY = levelPoints[2].y() 
             
        new_point_xp = (levelPoints[2].x() - 1.25)
        new_point_xl = (new_point_xp + levelPoints[2].x())/2     
        

        FeatureInserter(self.canvas, 'Point', self.ES, [self.QgsPointXY2(new_point_xp,surg_arstrY)] ,angle =  360 - self.angle)
        FeatureInserter(self.canvas, 'Point', self.SA, [self.QgsPointXY2(new_point_xl,surg_arstrY)] ,angle = 360 - self.angle)

        FeatureInserter(self.canvas,'LineString',self.OML,[levelPoints2[2] , self.QgsPointXY2(new_point_xl,surg_arstrY)] , class_type = self.classTypes[self.SA]) #0,1
        FeatureInserter(self.canvas,'LineString',self.OML,[self.QgsPointXY2(new_point_xl,surg_arstrY) , self.QgsPointXY2(new_point_xp,surg_arstrY)], class_type = self.classTypes[self.SA]) #0,1
        
        self.createMutipleGeomFeature(self.OML, 'cut_out', [levelPoints2[2],levelPoints2[3],levelPoints2[4]],angle=270 - self.object_angle , class_type=self.classTypes['cut_out'])

        self.createTransFeature(self.OML,self.OLL,'dist_tr',[levelPoints2[4],levelPoints2[5],levelPoints2[6]],
                                angle=270 - self.object_angle , class_type = self.classTypes['dist_tr'])
        

        if self.isFeederExist:
            FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [levelPoints2[6]],angle=270-self.object_angle) #90 bud
            FeatureInserter(self.canvas, 'LineString', self.ULL, [levelPoints2[6], levelPoints2[7]] , class_type=self.classTypes[self.ULL])  # Trans to Board
            FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [levelPoints2[7]],angle=270-self.object_angle)

            self.createMutipleGeomFeature(self.ULL, 'auto_switch', [levelPoints2[7], levelPoints2[8], levelPoints2[9]],angle=270-self.object_angle , class_type = self.classTypes['auto_switch'])
            self.lbverP.append(levelPoints2[9])

            lvBusbarY = levelPoints[9].y()
            lvSBrdY1 = (levelPoints[9].y() + levelPoints[10].y())/2
            lvSBrdY2 = (levelPoints[10].y() + levelPoints[11].y())/2
            FeatureInserter(self.canvas, 'Polygon', 'lv_s_brd', [self.QgsPointXY2(bRect.left,lvSBrdY1),self.QgsPointXY2(bRect.right,lvSBrdY1),self.QgsPointXY2(bRect.right,lvSBrdY2),self.QgsPointXY2(bRect.left,lvSBrdY2),self.QgsPointXY2(bRect.left,lvSBrdY1)]
            )  # lv board
            if self.IsBrdEearthExist:
                ull_first_point = self.QgsPointXY2(bRect.right,lvSBrdY1)
                ull_last_x_point = bRect.right + 0.5
                ull_last_point = self.QgsPointXY2(ull_last_x_point,lvSBrdY1)
                
                FeatureInserter(self.canvas, 'LineString', self.ULL, [ull_first_point, ull_last_point] , class_type=self.classTypes[self.ULL])
                FeatureInserter(self.canvas, 'Point', self.ES, [ull_last_point] ,angle =  360 - self.angle)
            # the first + 1 is the header of light feeder (above its busrbar and contactor (the first fuse_switch)
            # the second + 1 is because each n fuse_switch create n+1 parts

            lightX = None
            for i in range(1,nofeeders + 1):
                feederX = bRect.left + ((i-1) * feederHSpace) + (feederHSpace / 2)
                fuse_switch_top_line_first_point = self.QgsPointXY2(feederX,levelPoints[9].y())
                fuse_switch_point = self.QgsPointXY2(feederX,levelPoints[10].y())
                fuse_switch_below_line_second_point = self.QgsPointXY2(feederX, levelPoints[11].y())
                self.lbverP.append(fuse_switch_top_line_first_point)
                self.createMutipleGeomFeature(self.ULL, 'fuse_switch',[fuse_switch_top_line_first_point,fuse_switch_point,fuse_switch_below_line_second_point],angle=270-self.object_angle , class_type=self.classTypes['fuse_switch'])
                FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(feederX,levelPoints[11].y())],angle=270-self.object_angle)
                if i == 1 and noLightFeeders!=0:
                    lightX = feederX
                    FeatureInserter(self.canvas, 'Point', 'lighting_control_system', [self.QgsPointXY2(feederX, levelPoints[11].y())])
                else:
                    FeatureInserter(self.canvas, 'Point', 'lv_feeder', [self.QgsPointXY2(feederX,levelPoints[11].y())],angle=270-self.object_angle)

            if noLightFeeders != 0:
                self.createMutipleGeomFeature(self.ULL, 'contactor',[self.QgsPointXY2(lightX,levelPoints[11].y()),
                                                                    self.QgsPointXY2(lightX, levelPoints[12].y()),
                                                                    self.QgsPointXY2(lightX, levelPoints[13].y())],angle=270-self.object_angle , class_type=self.classTypes['contactor'])

                if noLightFeeders == 1:
                    FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(lightX, levelPoints[13].y())],angle=270-self.object_angle)

                    self.createMutipleGeomFeature(self.ULL, 'fuse_switch',[self.QgsPointXY2(lightX,levelPoints[13].y()),
                                                                    self.QgsPointXY2(lightX, levelPoints[14].y()),
                                                                    self.QgsPointXY2(lightX, levelPoints[15].y())],angle=270-self.object_angle,class_type=self.classTypes['fuse_switch'])
                    FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(lightX, levelPoints[15].y())],angle=270-self.object_angle)
                    FeatureInserter(self.canvas, 'Point', 'lv_feeder', [self.QgsPointXY2(lightX, levelPoints[15].y())],angle=270-self.object_angle)
                else:
                    # Creating light-busbar
                    lightBusbarWidth = self.calculateLightBusbarWidth(noLightFeeders,feederHSpace)
                    # we want the above drawn contactor to be at the middle of this light busbar
                    FeatureInserter(self.canvas, 'LineString', 'lv_busbar',
                                    [self.QgsPointXY2(lightX - (lightBusbarWidth / 2), levelPoints[13].y()),
                                    self.QgsPointXY2(lightX + (lightBusbarWidth / 2),levelPoints[13].y())])
                    light_feeder_x_parts = (noLightFeeders)
                    lightFeederHSpace = lightBusbarWidth / light_feeder_x_parts

                    for i in range(1,noLightFeeders + 1):
                        lightFeederX = lightX - (lightBusbarWidth / 2) + ((i - 1) * lightFeederHSpace) + (lightFeederHSpace / 2)
                        self.createMutipleGeomFeature(self.ULL, 'fuse_switch', [self.QgsPointXY2(lightFeederX, levelPoints[13].y()),
                                                                        self.QgsPointXY2(lightFeederX, levelPoints[14].y()),
                                                                        self.QgsPointXY2(lightFeederX, levelPoints[15].y())],angle=270-self.object_angle , class_type=self.classTypes['fuse_switch'])
                        FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(lightFeederX, levelPoints[15].y())],angle=270-self.object_angle)
                        FeatureInserter(self.canvas, 'Point', 'lv_feeder', [self.QgsPointXY2(lightFeederX, levelPoints[15].y())],angle=270-self.object_angle)
            FeatureInserter(self.canvas, 'LineString', 'lv_busbar', [self.QgsPointXY2(bRect.left,lvBusbarY),self.QgsPointXY2(bRect.right,lvBusbarY)] ,need_vertex=True , verPoint=self.lbverP)  # lv busbar
        
    def calculate_object_angle(self,angle):
        if 270 - angle < 0:
            angle =  angle - 360
        return angle
    
    def calculate_angle(self , angle):
        return angle%360 
        
            
    def setPointType(self):
        self.classTypes = {'recloser': -1, 'modem': -2, 'hv_switch': -3, 'sectionalizer': -4, 'pt': -5, 'arrow': -6, 'dist_tr': -7, 'contactor': -8,
                           'discnt_s': -9, 'circt_brk': -10, 'current_trans': -11, 'cut_out': -12, 'auto_switch': -13, 'fuse_switch': -14, 'auto_boostr': -15, 'surg_arstr' : -16 , 'mv_feeder':-17 , 'lv_feeder': -17,'ug_lv_line':-19}