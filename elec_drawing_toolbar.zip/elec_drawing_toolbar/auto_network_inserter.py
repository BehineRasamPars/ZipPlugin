from qgis.core import QgsFeature, QgsVectorLayer, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes, QgsLineString
from PyQt5.QtWidgets import QMessageBox, QProgressDialog, QProgressBar
from PyQt5.QtCore import QCoreApplication
import math
from .mylib import *
from .feature_inserter import FeatureInserter
from math import atan2,degrees

class AutoNetworkInserter:

    def featExistsInDist(self, layerName, qgsGeometry, dist):
        layer = get_layer_by_tablename(layerName)
        feats = layer.getFeatures()
        for feat in feats:
            if qgsGeometry.distance(feat.geometry()) <= dist:
                return feat
        return False

    def AngleBtw2Points(self,pointA, pointB):
        changeInX = pointB.x() - pointA.x()
        changeInY = pointB.y() - pointA.y()
        return degrees(atan2(changeInY,changeInX))

    def __init__(self, canvas, linearClass, pointClassArray, points,tableVals):
        #
        # This is to check if all layers exist in Project
        #
        dialog, bar = self.progdialog(0)
        bar.setValue(0)
        bar.setMaximum(100)
        QCoreApplication.processEvents()

        print("linearClass" , linearClass)
        print("pointClassArray" , pointClassArray)
        print("points" , points)
        print("tableVals" , tableVals)
        self.linearClass = linearClass
        self.points = points
        targetLineLayer = self.getLayerByName(canvas,linearClass)
        if not self.checkLayerExistance(targetLineLayer,linearClass):
            return
        targetPointLayers = []
        for aPointLayerName in pointClassArray:
            targetPointLayer = self.getLayerByName(canvas,aPointLayerName)
            targetPointLayers.append(targetPointLayer)
            if not self.checkLayerExistance(targetPointLayer, aPointLayerName):
                return
        # Step 1
        # First insert linear features
        #
        self.isOnePoint = False
        if 'no_subscribers' in pointClassArray:
            self.isOnePoint = True
            
        if not self.isOnePoint:
            print('***Step 1 Adding Lines *** pts :',len(points))
            self.newFeatures = {}
            for i in range(0,len(points)-1):
                bar.setValue(30*(i+1)/(len(points)))
                #QCoreApplication.processEvents()
                startSpanPoint = points[i]
                endSpanPoint = points[i+1]
                print("Index : ",i)
                targetLineLayer.beginEditCommand('ترسیم یک ' + linearClass)
                feature = QgsFeature()
                feature.setFields(targetLineLayer.fields())
                vals = {}
                for item in tableVals:
                    if item['name'] == linearClass:
                        vals = item['vals']
                for key,val in vals.items():
                    if val:
                        feature[key] = val
                if self.hasField('smtopoerror', targetLineLayer):
                    feature['smtopoerror'] = 0
                if self.hasField('smuserid', targetLineLayer):
                    feature['smuserid'] = 0
                geom = QgsGeometry().fromWkt(self.buildWKTLine(startSpanPoint,endSpanPoint))
                #
                #
                #
                feature.setGeometry(geom)
                if self.hasField( 'smlength', targetLineLayer):
                    feature['smlength'] = geom.length()
                if not linearClass in self.newFeatures.keys():
                    self.newFeatures[linearClass] = []
                    self.newFeatures[linearClass].append(feature)
                else:
                    self.newFeatures[linearClass].append(feature)
            
            QCoreApplication.processEvents()
        else : 
            self.newFeatures = {}

            # bar.setValue(30*(i+1)/(len(points)))
            #QCoreApplication.processEvents()
            startSpanPoint = points[0]
            endSpanPoint = points[len(points)-1]
            # print("Index : ",i)
            targetLineLayer.beginEditCommand('ترسیم یک ' + linearClass)
            feature = QgsFeature()
            feature.setFields(targetLineLayer.fields())
            vals = {}
            for item in tableVals:
                if item['name'] == linearClass:
                    vals = item['vals']
            for key,val in vals.items():
                if val:
                    feature[key] = val
            if self.hasField('smtopoerror', targetLineLayer):
                feature['smtopoerror'] = 0
            if self.hasField('smuserid', targetLineLayer):
                feature['smuserid'] = 0
            geom = QgsGeometry().fromWkt(self.buildWKTOneLine(points))
            #
            #
            #
            feature.setGeometry(geom)
            if self.hasField( 'smlength', targetLineLayer):
                feature['smlength'] = geom.length()
            if not linearClass in self.newFeatures.keys():
                self.newFeatures[linearClass] = []
                self.newFeatures[linearClass].append(feature)
            else:
                self.newFeatures[linearClass].append(feature)
                
            QCoreApplication.processEvents()
        # Step 2
        # Now insert point features
        #
        if not self.isOnePoint:
            print('***Step 2 Adding Points ***')
            for i in range(0, len(points)):
                bar.setValue(30+30 * (i + 1) / (len(points)))
                for pointLayerName in pointClassArray:
                    #for targetPointLayer in targetPointLayers:
                    targetPointLayer = self.getLayerByName(canvas, pointLayerName)
                    print("     drawing at vertext : ",i," a ",pointLayerName)
                    targetPointLayer.beginEditCommand('ترسیم یک ' + pointLayerName)
                    feature = QgsFeature()
                    feature.setFields(targetPointLayer.fields())

                    vals = {}
                    if i == 0 or i == len(points) - 1:
                        for item in tableVals:
                            if item['name'] == pointLayerName and item['note'] == 1:
                                vals = item['vals']
                    else:
                        for item in tableVals:
                            if item['name'] == pointLayerName and item['note'] == 2:
                                vals = item['vals']
                    for key,val in vals.items():
                        if val:
                            feature[key] = val

                    if self.hasField('smtopoerror', targetPointLayer):
                        feature['smtopoerror'] = 0
                    if self.hasField('smuserid', targetPointLayer):
                        feature['smuserid'] = 0
                    print("     Building geometry")
                    geom = QgsGeometry().fromWkt(self.buildWKTPoint(points[i]))
                    if self.hasField('angle', targetPointLayer):
                        print("     Calculating angle.")
                        feature['angle'] = round(self.getAngle(i))
                    print("     Setting geometry.")
                    feature.setGeometry(geom)

                    if (
                        i == 0
                        and pointLayerName in [ 'mv_pole', 'mv_isolator' ]
                        and (featExistsInPoint('mv_isolator', geom) or featExistsInPoint('mv_selfstand_terminal', geom))
                    ):
                        continue
                    if (
                        i == 0
                        and pointLayerName in [ 'lv_pole', 'lv_isolator' ]
                        and (featExistsInPoint('lv_isolator', geom) or featExistsInPoint('lv_selfstand_terminal', geom))
                    ):
                        continue


                    if (
                        i == 0
                        and pointLayerName in [ 'mv_pole' ]
                        and (self.featExistsInDist('mv_isolator', geom, 0.5))
                    ):
                        iso_feat = self.featExistsInDist('mv_isolator', geom, 0.5)
                        pole_feat = featExistsInPoint('mv_pole', iso_feat.geometry())
                        if pole_feat:
                            continue

                    if (
                        i == 0
                        and pointLayerName in [ 'mv_isolator' ]
                        and (self.featExistsInDist('mv_isolator', geom, 0.5))
                    ):
                        iso_feat = self.featExistsInDist('mv_isolator', geom, 0.5)
                        pole_feat = featExistsInPoint('mv_pole', iso_feat.geometry())
                        if pole_feat:
                            pole_layer = get_layer_by_tablename('mv_pole')
                            new_pole_geo = QgsGeometry.fromPointXY(QgsPointXY(
                                (pole_feat.geometry().asPoint().x() + geom.asPoint().x()) / 2,
                                (pole_feat.geometry().asPoint().y() + geom.asPoint().y()) / 2,
                                ))
                            pole_layer.changeGeometry(pole_feat.id(), new_pole_geo)

                            if not 'mv_jumpr' in self.newFeatures:
                                self.newFeatures['mv_jumpr'] = []
                            if not 'oh_mv_line' in self.newFeatures:
                                self.newFeatures['oh_mv_line'] = []

                            layer = get_layer_by_tablename('mv_jumpr')
                            fet = QgsFeature()
                            fet.setFields(layer.fields())
                            TheAngle = self.AngleBtw2Points(iso_feat.geometry().asPoint(), geom.asPoint())
                            TheAngle = round((180 - TheAngle) % 360)
                            fet['angle'] = TheAngle + 90
                            pole_layer.changeAttributeValue(pole_feat.id(), pole_layer.fields().indexOf('angle'), TheAngle + 90)
                            fet.setGeometry(new_pole_geo)
                            self.newFeatures['mv_jumpr'].append(fet)

                            layer = get_layer_by_tablename(linearClass)

                            fet = QgsFeature()
                            fet.setFields(layer.fields())
                            vals = {}
                            for item in tableVals:
                                if item['name'] == linearClass:
                                    vals = item['vals']
                            for key,val in vals.items():
                                if val:
                                    feature[key] = val
                            fet.setGeometry(QgsGeometry.fromPolylineXY([geom.asPoint(), new_pole_geo.asPoint()])) 
                            self.newFeatures[linearClass].append(fet)

                            fet = QgsFeature()
                            fet.setFields(layer.fields())
                            vals = {}
                            for item in tableVals:
                                if item['name'] == linearClass:
                                    vals = item['vals']
                            for key,val in vals.items():
                                if val:
                                    feature[key] = val
                            fet.setGeometry(QgsGeometry.fromPolylineXY([new_pole_geo.asPoint(), pole_feat.geometry().asPoint()]))
                            self.newFeatures[linearClass].append(fet)


                    if (
                        i == 0
                        and pointLayerName in [ 'lv_pole' ]
                        and (self.featExistsInDist('lv_isolator', geom, 0.5))
                    ):
                        iso_feat = self.featExistsInDist('lv_isolator', geom, 0.5)
                        pole_feat = featExistsInPoint('lv_pole', iso_feat.geometry())
                        if pole_feat:
                            continue

                    if (
                        i == 0
                        and pointLayerName in [ 'lv_isolator' ]
                        and (self.featExistsInDist('lv_isolator', geom, 0.5))
                    ):
                        iso_feat = self.featExistsInDist('lv_isolator', geom, 0.5)
                        pole_feat = featExistsInPoint('lv_pole', iso_feat.geometry())
                        if pole_feat:
                            pole_layer = get_layer_by_tablename('lv_pole')
                            new_pole_geo = QgsGeometry.fromPointXY(QgsPointXY(
                                (pole_feat.geometry().asPoint().x() + geom.asPoint().x()) / 2,
                                (pole_feat.geometry().asPoint().y() + geom.asPoint().y()) / 2,
                                ))
                            pole_layer.changeGeometry(pole_feat.id(), new_pole_geo)

                            if not 'lv_jumper' in self.newFeatures:
                                self.newFeatures['lv_jumper'] = []
                            if not 'oh_lv_line' in self.newFeatures:
                                self.newFeatures['oh_lv_line'] = []

                            layer = get_layer_by_tablename('lv_jumper')
                            fet = QgsFeature()
                            fet.setFields(layer.fields())
                            TheAngle = self.AngleBtw2Points(iso_feat.geometry().asPoint(), geom.asPoint())
                            TheAngle = round((180 - TheAngle) % 360)
                            fet['angle'] = TheAngle + 90
                            pole_layer.changeAttributeValue(pole_feat.id(), pole_layer.fields().indexOf('angle'), TheAngle + 90)
                            fet.setGeometry(new_pole_geo)
                            self.newFeatures['lv_jumper'].append(fet)

                            layer = get_layer_by_tablename(linearClass)

                            fet = QgsFeature()
                            fet.setFields(layer.fields())
                            vals = {}
                            for item in tableVals:
                                if item['name'] == linearClass:
                                    vals = item['vals']
                            for key,val in vals.items():
                                if val:
                                    feature[key] = val
                            fet.setGeometry(QgsGeometry.fromPolylineXY([geom.asPoint(), new_pole_geo.asPoint()])) 
                            self.newFeatures[linearClass].append(fet)

                            fet = QgsFeature()
                            fet.setFields(layer.fields())
                            vals = {}
                            for item in tableVals:
                                if item['name'] == linearClass:
                                    vals = item['vals']
                            for key,val in vals.items():
                                if val:
                                    feature[key] = val
                            fet.setGeometry(QgsGeometry.fromPolylineXY([new_pole_geo.asPoint(), pole_feat.geometry().asPoint()]))
                            self.newFeatures[linearClass].append(fet)


                    if not pointLayerName in self.newFeatures.keys():
                        self.newFeatures[pointLayerName] = []
                        self.newFeatures[pointLayerName].append(feature)
                    else:
                        self.newFeatures[pointLayerName].append(feature)
            
            QCoreApplication.processEvents()
        else :
            i = len(points)-1
            for pointLayerName in pointClassArray:
                # bar.setValue(30+30 * (i + 1) / (len(points)))
                #for targetPointLayer in targetPointLayers:
                targetPointLayer = self.getLayerByName(canvas, pointLayerName)
                targetPointLayer.beginEditCommand('ترسیم یک ' + pointLayerName)
                print("     drawing at vertext : ",i," a ",pointLayerName)
                feature = QgsFeature()
                feature.setFields(targetPointLayer.fields())

                vals = {}
                if i == 0 or i == len(points) - 1:
                    for item in tableVals:
                        if item['name'] == pointLayerName and item['note'] == 1:
                            vals = item['vals']
                else:
                    for item in tableVals:
                        if item['name'] == pointLayerName and item['note'] == 2:
                            vals = item['vals']
                for key,val in vals.items():
                    if val:
                        feature[key] = val

                if self.hasField('smtopoerror', targetPointLayer):
                    feature['smtopoerror'] = 0
                if self.hasField('smuserid', targetPointLayer):
                    feature['smuserid'] = 0
                print("     Building geometry")
                geom = QgsGeometry().fromWkt(self.buildWKTPoint(points[i]))
                if self.hasField('angle', targetPointLayer):
                    print("     Calculating angle.")
                    feature['angle'] = round(self.getSinglePoingAngle(i))
                print("     Setting geometry.")
                feature.setGeometry(geom)
                
                if not pointLayerName in self.newFeatures.keys():
                    self.newFeatures[pointLayerName] = []
                    self.newFeatures[pointLayerName].append(feature)
                else:
                    self.newFeatures[pointLayerName].append(feature)
        
            QCoreApplication.processEvents()
        # Step 3
        # now adding features to their relevant layer
        #
        print('****Step3 Add Features ***')
        self.wholeFeatures = {}
        i = 1
        for aClassName in self.newFeatures:
            bar.setValue(60 + 40 * (i) / (len(self.newFeatures)))
            i += 1
            print('     adding featuress of class',aClassName)
            targetLayer = self.getLayerByName(canvas, aClassName)
            targetLayer.startEditing()
            # This will write data to PG instantly
            # targetLayer.dataProvider().addFeatures(self.newFeatures[targetLayer])
            # targetLayer.dataProvider().forceReload()
            # targetLayer.commitChanges()
            
            targetLayer.addFeatures(self.newFeatures[aClassName])
            targetLayer.reload()
            targetLayer.endEditCommand()
            targetLayer.updateExtents()

        bar.setValue(100)
        QCoreApplication.processEvents()
        #if problem_occurred:
        #    targetLineLayer.destroyEditCommand()

        # Step 4
        # Adding mv jumper if needed
        #
        # print('****Step4 Add Jumpers **')
        # for aClassName in self.newFeatures:
            # #targetLayer = self.getLayerByName(canvas, aClassName)
            # if aClassName == 'oh_mv_line':
                # for i in range(len(self.newFeatures[aClassName])-1):
                    # firstLine = self.newFeatures[aClassName][i]
                    # secLine = self.newFeatures[aClassName][i+1]
                    # crossAngle = self.getCrossAngle(firstLine,secLine)
                    # if crossAngle > 15:
                        # movement = 0.5 #in meter
                        # #first_line.geometry().moveVertex(movement,movement,1)
                        # #sec_line.geometry().moveVertex(movement,movement,0)
                        # #print(str(first_line.geometry().vertexAt(1)))
                        # self.editFirstLineGeometry(firstLine)
                        
        canvas.refresh()
        print("AutoNetwork finished...")


    # def editFirstLineGeometry(self,firstLine):
        # firstPoint = firstLine.geometry().vertexAt(0)
        # secPoint = firstLine.geometry().vertexAt(1)
        # direction = firstLine.geometry().angleAtVertex(0)
        # deltaX = 0.5*math.cos(direction)
        # deltaY = 0.5*math.sin(direction)
        # newSecPoint = QgsPoint(secPoint.x()-deltaX,secPoint.y()-deltaY)
        # print('newSecPoint: ',newSecPoint)
        # firstLine.setGeometry(QgsLineString(firstPoint,newSecPoint))
        
    # def getCrossAngle(self,line1,line2):
        # a1 = line1.geometry().angleAtVertex(0)
        # a2 = line2.geometry().angleAtVertex(0)
        # dif = abs(a1-a2) * 180/3.1415
        # return dif
      
    def getAngle(self,i):
        print("linearClass : ",self.linearClass,"     getAngle(",i,") vs ",len(self.newFeatures[self.linearClass])-1)
        if 0 == i:
            print("     Start node angle detected : ",i)
            ang = self.newFeatures[self.linearClass][i].geometry().angleAtVertex(0) * 180/3.1415
            return ang % 360
        if i == len(self.points)-1:
            print("     End node angle detected : ",i)
            ang = self.newFeatures[self.linearClass][i-1].geometry().angleAtVertex(0) * 180/3.1415
            return ang % 360

        print("No of Lines : ",len(self.newFeatures[self.linearClass]))
        print("Line [",i,"] : ",self.newFeatures[self.linearClass][i])
        print("geom : ",self.newFeatures[self.linearClass][i].geometry())
        angle2 = self.newFeatures[self.linearClass][i].geometry().angleAtVertex(0) * 180/3.1415
        angle1 = self.newFeatures[self.linearClass][i - 1].geometry().angleAtVertex(1) * 180 / 3.1415
        print('Angle Vertex(',i,') = ',angle1,' ',angle2)
        ang = (( angle1 + angle2 ) / 2) + 90
        return ang % 360

    def getSinglePoingAngle(self , i):
        if i == len(self.points)-1:
            print("     End node angle detected : ",i)
            if len(self.newFeatures[self.linearClass]) == 1:
                print("tuie if angle")
                vertexLen =self.newFeatures[self.linearClass][0].geometry().vertices()
                # vertex_len = 0
                vertex_len = len([v for v in vertexLen])
                # for v in vertexLen :
                #     vertex_len += 1
                #     print("akharin vertext : ",v.x(),v.y())
                ang = self.newFeatures[self.linearClass][0].geometry().angleAtVertex(vertex_len-1) * 180/3.1415
                final_ang = (ang % 360)+90
                if final_ang > 360:
                    return final_ang - 360
                return final_ang
        
    def checkLayerExistance(self,targetLayer,layername):
        if targetLayer is None:
            msgBox = QMessageBox(QMessageBox.Critical, "GeoPower", "لایه ای به این نام وجود ندارد، تنظیمات پایگاه داده نادرست است، لطفاً به شرکت رسام تماس بگيرید"+"\n"+layername)
            msgBox.show()
            msgBox.exec()
            return False
        else:
            return True

    def hasField(self,aFieldName,alayer):
        for afield in alayer.fields():
            if afield.name() == aFieldName:
                return True
        return False


    def getLayerByName(self,canvas, internalName):
        layers = canvas.layers()
        for aMapLayer in layers:
            parts = aMapLayer.source().split("\"")
            if len(parts) < 4:
                continue
            aName = parts[3]
            if aName == internalName:
                print(aMapLayer.name(), "  ", internalName)
                return aMapLayer
        return None

    def buildWKTLine(self,startPoint,endPoint):
        geomString = 'LineString('
        firstPoint = True
        for apoint in [startPoint,endPoint]:
            if firstPoint:
                geomString += str(apoint.x()) + ' ' + str(apoint.y())
                firstPoint = False
            else:
                geomString += ','+str(apoint.x()) + ' ' + str(apoint.y())
        geomString += ')'
        return geomString

    def buildWKTOneLine(self,points):
        geomString = 'LineString('
        firstPoint = True
        for apoint in points:
            if firstPoint:
                geomString += str(apoint.x()) + ' ' + str(apoint.y())
                firstPoint = False
            else:
                geomString += ','+str(apoint.x()) + ' ' + str(apoint.y())
        geomString += ')'
        return geomString
    
    def buildWKTPoint(self,apoint):
        geomString = 'Point('+str(apoint.x()) + ' ' + str(apoint.y())+')'
        return geomString

    def getInternalNameOfLayer(self,alayer):
        parts = alayer.source().split("\"")
        if len(parts) < 4:
            return None
        aName = parts[3]
        return aName

    def progdialog(self,progress):
        dialog = QProgressDialog()
        bar = QProgressBar(dialog)
        bar.setTextVisible(True)
        bar.setValue(progress)        
        dialog.setBar(bar)
        dialog.setWindowTitle("ترسیم اتوماتیک")
        dialog.setAutoClose(True)
        dialog.setLabelText("لطفاً صبر کنید")        
        dialog.setMinimumWidth(300)
        dialog.show()
        return dialog, bar