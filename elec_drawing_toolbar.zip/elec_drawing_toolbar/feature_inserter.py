from qgis.core import QgsFeature,QgsVectorLayer, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes,QgsVectorLayerEditUtils,QgsVertexIterator

from PyQt5.QtWidgets import QMessageBox
class FeatureInserter:
    def __init__(self,canvas, wktGeometryType, layername, points,angle=None, class_type = None , need_vertex=False , verPoint=[]):
        targetLayer = self.getLayerByName(canvas,layername)
        if targetLayer is None:
            msgBox = QMessageBox(QMessageBox.Critical, "GeoPower", "لایه ای به این نام وجود ندارد، تنظیمات پایگاه داده نادرست است، لطفاً به شرکت رسام تماس بگيرید"+"\n"+layername)
            msgBox.show()
            msgBox.exec()
            return
        targetLayer.beginEditCommand('ترسیم یک ' + layername)
        problem_occurred = False
        feature = QgsFeature()
        if angle is None:
            self.angle = 0
        else:
            self.angle = round(angle)
            
        feature.setFields(targetLayer.fields())
        fields = targetLayer.fields()
        print(fields)
        feature.initAttributes(fields.count())   
        provider = targetLayer.dataProvider()              
        for i in range(fields.count()):
            feature.setAttribute(i, provider.defaultValue(i))

        if self.hasField('smtopoerror', targetLayer):
            feature['smtopoerror'] = 0
        if self.hasField('smuserid', targetLayer):
            feature['smuserid'] = 0

        if wktGeometryType == 'Polygon':
            geomString = wktGeometryType+'(('
            firstPoint = True
            for apoint in points:
                if firstPoint:
                    geomString += str(apoint.x()) + ' ' + str(apoint.y())
                    firstPoint = False
                else:
                    geomString += ','+str(apoint.x()) + ' ' + str(apoint.y())
            geomString += '))'
        else:
            geomString = wktGeometryType+'('
            firstPoint = True
            for apoint in points:
                if firstPoint:
                    geomString += str(apoint.x()) + ' ' + str(apoint.y())
                    firstPoint = False
                else:
                    geomString += ','+str(apoint.x()) + ' ' + str(apoint.y())
            geomString += ')'
        
        #print("WKT : ", geomString)
        geom = QgsGeometry().fromWkt(geomString)
        if need_vertex:
            for s_point in verPoint:
                p1, at, b1, after, d1 = geom.closestVertex(s_point)
                data = geom.closestSegmentWithContext(s_point)
                if at == 0:
                    if data[0] < 0.015:
                        geom.insertVertex(s_point.x(),s_point.y(),after)
                    else:
                        geom.insertVertex(s_point.x(),s_point.y(),0)
                elif at==-1:
                    if data[0] < 0.015:
                # insert after last vertex
                        geom.insertVertex(s_point.x(),s_point.y(), at)
                    else:
                    # insert into last segment
                        last = geom.vertexAt(at)
                        geom.moveVertex(s_point.x(),s_point.y(), at)
                        geom.insertVertex(last.x(), last.y(), at)
                else:
                        geom.insertVertex(s_point.x(),s_point.y(), data[2])
                    
                    
            
        if wktGeometryType == 'LineString':
            # Line does not have an angle, but when we are drawing a switch/trans which has a point and two line
            # and FeatureInserter draws each of them separately, we derive the angle for point from angleAtvertex of
            # connected lines. so we FeatureInserter is drawing a line, we save angle of that line (at 0 vertex)
            # so we can retrive it whem drawing line has finished and set the point angle
            # check func insertFeature in draw_line_and_point.py to see how this angle is being used.
            self.angle = round(geom.angleAtVertex(0))
            #print("Calculated Line Angle : ", self.angle)
        else:
            if self.hasField('angle',targetLayer):
                #print("Setting Point Angle : ",self.angle)
                feature['angle'] = round(self.angle) #int(self.angle * 180 / 3.1415)
        if self.hasField('class_type',targetLayer):
                feature['class_type'] = class_type

        feature.setGeometry(geom)
        if self.hasField( 'smlength', targetLayer):
            feature['smlength'] = geom.length()


        targetLayer.startEditing()
        # This will write data to PG instantly
        # targetLayer.dataProvider().addFeatures([feature])
        # targetLayer.dataProvider().forceReload()
        targetLayer.addFeatures([feature])
        targetLayer.reload()

        #targetLayer.commitChanges()
        if problem_occurred:
            targetLayer.destroyEditCommand()
        targetLayer.endEditCommand()
        canvas.refresh()
        #print(layername," feature just Created...")
        targetLayer.updateExtents()


    def hasField(self,aFieldName,alayer):
        for afield in alayer.fields():
            if afield.name() == aFieldName:
                return True
        return False


    def getLayerByName(self,canvas, internalName):
        layers = canvas.layers()
        for aMapLayer in layers:
            parts = aMapLayer.source().split("\"")
            if len(parts) < 4:
                continue
            aName = parts[3]
            if aName == internalName:
                #print(aMapLayer.name(), "  ", internalName)
                return aMapLayer
        return None

    def getInternalNameOfLayer(self,alayer):
        parts = alayer.source().split("\"")
        if len(parts) < 4:
            return None
        aName = parts[3]
        return aName
