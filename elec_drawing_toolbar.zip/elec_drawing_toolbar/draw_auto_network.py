import PyQt5
from PyQt5.QtWidgets import QRubberBand
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtCore import Qt, QRectF
from qgis.core import QgsFeature,QgsFeatureRequest, QgsVectorLayer, QgsRectangle, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob, QgsWkbTypes
from qgis.gui import QgsSnapIndicator,QgsMapTool, QgsMapCanvas, QgsVertexMarker, QgsMapCanvasItem, QgsRubberBand
from .feature_inserter import FeatureInserter
from .auto_network_inserter import AutoNetworkInserter
class DrawAutoNetwork(QgsMapTool):
    """QGIS Plugin Implementation."""

    def __init__(self, canvas,linearClass,pointClassArray,tableVals):
        print("Starting Auto network...", linearClass)
        self.canvas = canvas
        self.linearClass = linearClass
        self.pointClassArray = pointClassArray
        self.points = []
        QgsMapTool.__init__(self, self.canvas)
        self.snapIndicator = QgsSnapIndicator(canvas)
        self.snapper = self.canvas.snappingUtils()
        self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rubberBand.setColor(Qt.blue)
        self.rubberBand.setWidth(3)
        self.tableVals = tableVals
        self.reset()


    def reset(self):
        self.points = []
        self.isEmittingPoint = False
        self.rubberBand.reset(True)

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        snapMatch = self.snapper.snapToMap(event.pos())
        self.snapIndicator.setMatch(snapMatch)
        self.snapPoint = snapMatch.point()
        if len(self.points)==0:
            return
        if not self.isEmittingPoint:
            return
        x = event.pos().x()
        y = event.pos().y()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.showRubber(point)

    def canvasReleaseEvent(self, event):
        # Get the click
        if event.button() == Qt.RightButton:
            self.isEmittingPoint = False
            #self.showRubber(None,True)
            self.insertFeature()
            return
        point = QgsPointXY(self.snapPoint.x(),self.snapPoint.y())
        if self.snapPoint.x() == 0.0 and self.snapPoint.y() == 0.0:
            x = event.pos().x()
            y = event.pos().y()
            point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        if len(self.points) == 0:
            self.points.append(point)
            self.isEmittingPoint = True
        else:
            self.points.append(point)


    def insertFeature(self):
        self.showRubber(None,True)
        self.rubberBand.hide()
        AutoNetworkInserter(self.canvas,self.linearClass,self.pointClassArray,self.points,self.tableVals)
        self.reset()

    def deactivate(self):
        QgsMapTool.deactivate(self)
        self.rubberBand.hide()
        self.deactivated.emit()

    def activate(self):
        QgsMapTool.activate(self)

    def showRubber(self,endPoint,DRAW_LAST=None):
        self.rubberBand.reset(QgsWkbTypes.LineGeometry)
        for apoint in self.points:
            self.rubberBand.addPoint(apoint)
        if DRAW_LAST==None:
            self.rubberBand.addPoint(endPoint)
        self.rubberBand.show()