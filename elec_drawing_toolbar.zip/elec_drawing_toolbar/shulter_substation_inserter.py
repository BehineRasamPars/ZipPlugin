from qgis.core import QgsPointXY
from PyQt5.QtGui import QTransform
from PyQt5.QtWidgets import QMessageBox
from .utils.BRPRect import BRPRect
from .feature_inserter import FeatureInserter
from .insert_substation import SubstationInserter
from math import sin, cos, radians, pi, hypot

class ShulterSubstationInserter(SubstationInserter):
    LEVELS = 16
    CLASS_TYPE = 'shulter'

    def rotate_point(self, point, angle, center_point=(0, 0)):
        """Rotates a point around center_point(origin by default)
        Angle is in degrees.
        Rotation is counter-clockwise
        """
        angle_rad = radians(angle % 360)
        # Shift the point so that center_point becomes the origin
        new_point = (point[0] - center_point[0], point[1] - center_point[1])
        new_point = (new_point[0] * cos(angle_rad) - new_point[1] * sin(angle_rad),
                    new_point[0] * sin(angle_rad) + new_point[1] * cos(angle_rad))
        # Reverse the shifting we have done
        new_point = (new_point[0] + center_point[0], new_point[1] + center_point[1])
        return new_point


    def QgsPointXY2(self, x, y):
        newPoint = self.rotate_point([x,y], self.angle, self.center)
        newPointQgs = QgsPointXY(newPoint[0], newPoint[1])
        return newPointQgs

    def __init__(self,canvas,bRect,noOut,angle):
        self.center = [
            (bRect.left + bRect.right) / 2,
            (bRect.top + bRect.bottom) / 2
        ]
        self.angle = self.calculate_angle(angle)
        self.axis_object_angle = self.angle
        self.object_angle = self.calculate_object_angle(self.angle)
        self.canvas = canvas
        self.width = bRect.getWidth()
        self.height = bRect.getHeight()
        vertical_unit = self.height / self.LEVELS
        topMiddle = bRect.getTopMiddle()
        levelPoints = []
        self.lbverP = []
        for i in range(0,self.LEVELS):
            levelPoints.append(QgsPointXY(topMiddle.x(),topMiddle.y()-(i*vertical_unit)))
        levelPoints2 = []
        for i in range(0,self.LEVELS):
            levelPoints2.append(self.QgsPointXY2(topMiddle.x(),topMiddle.y()-(i*vertical_unit)))

        self.setPointType()
        
        
        feeder_x_parts = (noOut)
        asHSpace =  self.width / feeder_x_parts
        lvBusbarY = levelPoints[0].y()
        if noOut != 0:
            for i in range(1,noOut + 1):
                fuseswitchX = bRect.left + ((i-1) * asHSpace) + (asHSpace / 2)
                fuse_switch_top_line_first_point = self.QgsPointXY2(fuseswitchX,levelPoints[0].y())
                fuse_switch_point = self.QgsPointXY2(fuseswitchX,levelPoints[1].y())
                fuse_switch_below_line_second_point = self.QgsPointXY2(fuseswitchX, levelPoints[2].y())
                self.lbverP.append(fuse_switch_top_line_first_point)
                self.createMutipleGeomFeature(self.ULL, 'fuse_switch',[fuse_switch_top_line_first_point,fuse_switch_point,fuse_switch_below_line_second_point],angle=270-self.object_angle , class_type=self.classTypes['fuse_switch'])
                FeatureInserter(self.canvas, 'Point', 'lv_c_hd', [self.QgsPointXY2(fuseswitchX,levelPoints[2].y())],angle=270-self.object_angle)
            
        FeatureInserter(self.canvas, 'Point', self.CLASS_TYPE, [self.QgsPointXY2(levelPoints[0].x(),levelPoints[0].y())], angle= 360 - self.axis_object_angle)
        #FeatureInserter(self.canvas, 'Point', self.CLASS_TYPE, [self.QgsPointXY2(levelPoints[0].x(),levelPoints[0].y())], angle= 180 - self.object_angle)
        self.lbverP.append(self.QgsPointXY2(levelPoints[0].x(),levelPoints[0].y()))
        FeatureInserter(self.canvas, 'LineString', self.LB, [self.QgsPointXY2(bRect.left,lvBusbarY),self.QgsPointXY2(bRect.right,lvBusbarY)] ,need_vertex=True , verPoint=self.lbverP)  # lv busbar

    def calculate_object_angle(self,angle):
        if 270 - angle < 0:
            angle =  angle - 360
            if self.CLASS_TYPE in ('shulter'):
                self.axis_object_angle = angle +360
        return angle
    
    def calculate_angle(self , angle):
        return angle%360 
        
            
    def setPointType(self):
        self.classTypes = {'recloser': -1, 'modem': -2, 'hv_switch': -3, 'sectionalizer': -4, 'pt': -5, 'arrow': -6, 'dist_tr': -7, 'contactor': -8,
                           'discnt_s': -9, 'circt_brk': -10, 'current_trans': -11, 'cut_out': -12, 'auto_switch': -13, 'fuse_switch': -14, 'auto_boostr': -15, 'surg_arstr' : -16 , 'mv_feeder':-17 , 'lv_feeder': -17,'ug_lv_line':-19}