#
# Create a Rectangle out of two points
# and returns various structures.
# Author : Iman Hosseini Nia, 2020
# License : BSD

from qgis.core import QgsPoint, QgsPointXY,QgsRectangle
from qgis.PyQt.QtCore import Qt,QRect,QPoint

class BRPRect:
    # REMOVE FIX
    # if shoudlBeClosed is True it adds the first coordinate at the end of the coordinates vector
    # which will be interpreted as a closed polygon by QGIS (and also other gis systems
    #
    def __init__(self):
        # The actual constructors are at the below (createFromCenter,createWithPoints)
        pass

    def createFromCenter(self,centerPoint,recWidth,recHeight):
        self.left = centerPoint.x() - (recWidth/2)
        self.right = centerPoint.x() + (recWidth/2)
        self.bottom = centerPoint.y() - (recHeight/2)
        self.top = centerPoint.y() + (recHeight/2)
        self.bottomLeft = QgsPointXY(self.left,self.bottom)
        self.topRight = QgsPointXY(self.right, self.top)        
        return self

    def createWithPoints(self,start_p,end_p):
        self.left = min(start_p.x(), end_p.x())
        self.right = max(start_p.x(), end_p.x())
        self.bottom = min(start_p.y(), end_p.y())
        self.top = max(start_p.y(), end_p.y())
        self.bottomLeft = QgsPointXY(self.left,self.bottom)
        self.topRight = QgsPointXY(self.right, self.top)
        return self

    def asQgsPointVector(self,closed=False):
        vec = [QgsPoint(self.left, self.bottom), QgsPoint(self.left, self.top), QgsPoint(self.right, self.top),
               QgsPoint(self.right, self.bottom)]        
        vec.append(QgsPoint(self.left,self.bottom))
        return vec

    def asQgsPointXYVector(self,closed=False):
        vec = [QgsPointXY(self.left, self.bottom), QgsPointXY(self.left, self.top), QgsPointXY(self.right, self.top),
               QgsPointXY(self.right, self.bottom)]
        vec.append(QgsPointXY(self.left,self.bottom))
        return vec

    def getWidth(self):
        return self.right-self.left

    def getHeight(self):
        return self.top-self.bottom

    def asQRect(self):
        return QRect(QPoint(self.left,self.bottom),QPoint(self.right,self.top))

    def asQgsRectangle(self):
        return QgsRectangle(self.left,self.bottom,self.right,self.top)

    def getTopMiddle(self):
            return QgsPointXY( (self.left+self.right)/2,self.top)