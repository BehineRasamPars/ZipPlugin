import psycopg2

def do():
    conn = psycopg2.connect(host="localhost",database="electricity_red",user="postgres",password="2966")
    cur = conn.cursor()
    
    cur.execute('DROP SCHEMA IF EXISTS cartable CASCADE;')
    cur.execute('CREATE SCHEMA cartable;')
    cur.execute('UPDATE pg_extension SET extrelocatable = TRUE WHERE extname = \'cartable\';')

    cur.execute('select t.table_name from information_schema.tables t inner join information_schema.columns c on c.table_name = t.table_name and c.table_schema = t.table_schema where c.column_name = \'smid\' and t.table_schema in (\'public\') and t.table_type = \'BASE TABLE\'')

    for row in cur.fetchall():
        cur.execute('create table cartable.'+row[0]+' (like '+row[0]+' including all);')

    conn.commit()
    cur.close()
        
if __name__ == '__main__':
    do()