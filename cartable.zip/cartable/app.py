import sys
from .DataAccess import DataAccess
from .mylib import *
from .rassam import *
import xml.etree.ElementTree as ET
from .resources import *
from PyQt5 import QtWidgets, QtGui, uic, QtCore
from qgis.PyQt.QtGui import QIcon, QStandardItemModel, QStandardItem
from qgis.utils import iface, Qgis
import xlwt
from .CreateProject import Ui_MainWindow as CreateProWindow
from .ListOfProject import Ui_MainWindow as ListOfProjectsWindow
from .CartableUI import Ui_MainWindow as CartableWindow
from .userSelect import Ui_MainWindow as UserWindow
from .description import Ui_MainWindow as DescriptionWindow
from .workFlow import Ui_MainWindow as WorkFlowWindow
from .projectFeatures import Ui_MainWindow as projectFeatureWindow
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QTableWidgetItem, QInputDialog
from .jalaali import Jalaali
from qgis.core import QgsRectangle
import re
import psycopg2.extras
from .rassam import *
import json


class CreateProGUI(QtWidgets.QMainWindow):

    dataAccess = None
    usePlugin = None
    version = 0
    lineDistCalculated = False
    winWorkflow_dest = QtWidgets.QDialog()
    winWorkflow_workf = QtWidgets.QDialog()
    winWorkflow_projf = QtWidgets.QDialog()

    def __init__(self):
        super().__init__()
        self.dataAccess = DataAccess()
        # self.initCreateProjectUI()

    def initCreateProjectUI(self):
        self.cpui = CreateProWindow()
        self.cpui.setupUi(self)
        self.setFixedSize(283, 446)
        self.cpui.create_BTN.clicked.connect(self.create_project_clicked)
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app2.png'))

    def initListOfProjectUI(self):
        self.lpui = ListOfProjectsWindow()
        self.lpui.setupUi(self)
        self.setFixedSize(602, 310)
        self.lpui.pushButton.clicked.connect(self.save_btn_clicked)
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app2.png'))

    def initCartableUI(self):
        self.cui = CartableWindow()
        self.cui.setupUi(self)
        self.setFixedSize(1000, 310)
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app2.png'))
        self.cui.details_Table.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.cui.cartable_CHB.stateChanged.connect(self.cartable_st_change)
        self.cui.details_Table.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.cui.details_Table.customContextMenuRequested.connect(self.generateMenu)
        self.cui.details_Table.viewport().installEventFilter(self)
        self.fill_changable_projects_window(True)

    def initUserWindow(self):
        self.uui = UserWindow()
        # self.uui = CartableWindow()
        self.uui.setupUi(self)       
        self.setFixedSize(330, 300)
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app2.png'))
        self.addUserToList('access')
        self.uui.selfOwner_CMB.currentIndexChanged.connect(self.sourceUserChanged)
        self.uui.SaveBTN.clicked.connect(self.saveUserAccess)
        
    def initDescriptionUI(self):
        self.dui = DescriptionWindow()   
        self.dui.setupUi(self.winWorkflow_dest)
        self.winWorkflow_dest.show()
        # self.setFixedSize(330, 300)
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app2.png'))
        self.addUserToList('description')
        self.dui.destOwner_CMB.currentIndexChanged.connect(self.destUserChanged)
        self.dui.send_BTN.clicked.connect(self.sendDescription)
    
    def initWorkFlowUI(self):
        self.wfui = WorkFlowWindow()
        self.wfui.setupUi(self.winWorkflow_workf)
        self.winWorkflow_workf.show()
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app2.png'))
        self.onLoadWorkFlow()
        self.wfui.tableDetails.clicked.connect(self.rowClicked)

    def initProjectFeaturesUI(self):
        self.pF = projectFeatureWindow()
        self.pF.setupUi(self.winWorkflow_projf)
        self.winWorkflow_projf.show()
        self.setWindowIcon(QtGui.QIcon(':gui/icons/app2.png'))
        self.pF.ins_tableName_TBL.clicked.connect(self.ins_tab_clicked)
        self.pF.upd_tableName_TBL.clicked.connect(self.upd_tab_clicked)
        self.pF.del_tableName_TBL.clicked.connect(self.del_tab_clicked)
        self.pF.upd_Features_TBL.clicked.connect(self.detect_changes)
        
        self.pF.ins_Features_TBL.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.pF.ins_Features_TBL.customContextMenuRequested.connect(self.insFgenerateMenu) # sakhte function generated menu bara har jadval 
        self.pF.ins_Features_TBL.viewport().installEventFilter(self)

        self.pF.upd_Features_TBL.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.pF.upd_Features_TBL.customContextMenuRequested.connect(self.updFgenerateMenu) # sakhte function generated menu bara har jadval 
        self.pF.upd_Features_TBL.viewport().installEventFilter(self)

        self.pF.del_Features_TBL.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.pF.del_Features_TBL.customContextMenuRequested.connect(self.delFgenerateMenu) # sakhte function generated menu bara har jadval 
        self.pF.del_Features_TBL.viewport().installEventFilter(self)

        self.pF.ins_tableName_TBL.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.pF.ins_tableName_TBL.customContextMenuRequested.connect(self.insgenerateMenu) # sakhte function generated menu bara har jadval 
        self.pF.ins_tableName_TBL.viewport().installEventFilter(self)

        self.pF.upd_tableName_TBL.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.pF.upd_tableName_TBL.customContextMenuRequested.connect(self.updgenerateMenu) # sakhte function generated menu bara har jadval 
        self.pF.upd_tableName_TBL.viewport().installEventFilter(self)

        self.pF.del_tableName_TBL.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.pF.del_tableName_TBL.customContextMenuRequested.connect(self.delgenerateMenu) # sakhte function generated menu bara har jadval 
        self.pF.del_tableName_TBL.viewport().installEventFilter(self)


        self.pF.ins_tableName_TBL.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self.pF.upd_tableName_TBL.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self.pF.del_tableName_TBL.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
                     
    def msgUser(self, type, msg=None):
        self.statusLabel.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"),
                             QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"),
                             QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.statusLabel.setText('لطفا صبر کنید ...')
            self.statusLabel.setStyleSheet('color: rgb(60, 60, 60)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()

    def getAllUsers(self):
        cursor = self.conn.cursor()
        query = '''SELECT usename AS role_name FROM pg_catalog.pg_user'''
        cursor.execute(query)
        all_user = cursor.fetchall()   
        return all_user
        
    def addUserToList(self , ui):
        allUser = self.getAllUsers()
        if ui == 'access':
            for eachUser in allUser :
                self.uui.selfOwner_CMB.addItem(eachUser[0])
            self.fillSelectedUsers()  
        elif ui == 'description':
            cursor = self.conn.cursor()
            cursor.execute("SELECT dest_user FROM cartable.project_send WHERE source_user = '" + self.dbconn.getUsername() +"'")
            for eachUser in cursor.fetchall():
                self.dui.destOwner_CMB.addItem(eachUser[0])
        
    def fillSelectedUsers(self):
        self.uui.otherOwner_CMB.clear()
        for eachUser in self.getAllUsers():
            self.uui.otherOwner_CMB.addItem(eachUser[0])
        self.uui.otherOwner_CMB.removeItem(self.uui.otherOwner_CMB.findText(self.uui.selfOwner_CMB.currentText()))
        cursor = self.conn.cursor()
        cursor.execute("SELECT dest_user FROM cartable.project_send WHERE source_user = '" + self.uui.selfOwner_CMB.currentText()+"'")
        for a_user in cursor.fetchall():
            print(a_user)
            user_ind = self.uui.otherOwner_CMB.findText(a_user[0])
            print(user_ind)
            item = self.uui.otherOwner_CMB.model().item(user_ind, 0)
            print(item)
            item.setCheckState(QtCore.Qt.Checked)
    
    def destUserChanged(self):
        print(self.dui.destOwner_CMB.currentText())
    # in self.wfui ro ehtemalan to ye function sakhtid ke seda zade nemishe vali tu ye code ejrash kardi , bedune inke sakhte beshe dare estefade mishe 
    def onLoadWorkFlow(self):
        query = "select smid, sender, reciever, sender_operation, send_time from cartable.project_workflow WHERE project_id = " + self.cui.details_Table.selectedItems()[0].text()+" ORDER BY send_time DESC;"
        cursor = self.conn.cursor()
        cursor.execute(query)
        for row in cursor.fetchall():
            rows = self.wfui.tableDetails.rowCount()
            self.wfui.tableDetails.setRowCount(rows + 1)

            self.wfui.tableDetails.setItem(rows, 0, QTableWidgetItem(str(row[0] if row[0] is not None else ''))) # smid
            self.wfui.tableDetails.setItem(rows, 1, QTableWidgetItem(str(row[1] if row[1] is not None else ''))) # sender
            self.wfui.tableDetails.setItem(rows, 2, QTableWidgetItem(str(row[2] if row[2] is not None else ''))) # reciever
            self.wfui.tableDetails.setItem(rows, 3, QTableWidgetItem(str(row[3] if row[3] is not None else ''))) # sender_operation
            geog_date = row[4].strftime("%x")
            geog_time = row[4].strftime("%H:%M:%S")
            geog_date_part = geog_date.split('/')
            jal_date = Jalaali.to_jalaali(int('20'+geog_date_part[2]),int(geog_date_part[0]),int(geog_date_part[1]))
            jal_date_ready = str(jal_date['jy'])+'/'+str(jal_date['jm'])+'/'+str(jal_date['jd']) + ' ' + geog_time
            self.wfui.tableDetails.setItem(rows, 4, QTableWidgetItem(jal_date_ready)) # time_created

    def rowClicked(self):
        cursor = self.conn.cursor()
        cursor.execute('SELECT reciever,sender_message FROM cartable.project_workflow WHERE smid = ' + self.wfui.tableDetails.selectedItems()[0].text())
        res = cursor.fetchall()[0]
        if res[0] is None or len(res[0]) == 0:
            self.wfui.Message_TE.setEnabled(False)
            self.wfui.Message_TE.setText('')
        else:
            self.wfui.Message_TE.setEnabled(True)
            self.wfui.Message_TE.setText(res[1])

    def sendDescription(self):
        project_smid = self.cui.details_Table.selectedItems()[0].text()
        cursor = self.conn.cursor()
        cursor.execute("UPDATE cartable.project SET current_responsible = '" + self.dui.destOwner_CMB.currentText() +"' , status = 'در دست بررسی' WHERE smid = "+project_smid+";INSERT INTO cartable.project_workflow(project_id, sender, reciever, sender_message, sender_operation, send_time) VALUES ("+project_smid+",'"+self.dbconn.getUsername()+"','"+self.dui.destOwner_CMB.currentText()+"','"+self.dui.description_TE.toPlainText()+"','ارسال',current_timestamp AT time zone 'Asia/Tehran')")
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Information)
        msgBox.setText("پروژه با موفقیت منتقل شد.")
        msgBox.setWindowTitle("موفقیت")
        msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
        msgBox.exec_()
        self.conn.commit()
        self.fill_changable_projects_window(True)
        self.winWorkflow_dest.close()
        
    def saveUserAccess(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT dest_user FROM cartable.project_send WHERE source_user = '" + self.uui.selfOwner_CMB.currentText()+"'")
        current_users = []
        new_users = []
        for a_c in cursor.fetchall():
            current_users.append(a_c[0])
        
        for a_p in self.uui.otherOwner_CMB.currentText().split(','):
            new_users.append(a_p.strip())
        
        for a_cur_user in current_users:
            if not a_cur_user in new_users:
                cursor.execute("DELETE FROM cartable.project_send WHERE source_user = '" + self.uui.selfOwner_CMB.currentText()+"' AND dest_user = '" + a_cur_user + "'")
        
        for a_new_user in new_users:
            if not a_new_user in current_users:
                cursor.execute("INSERT INTO cartable.project_send(source_user, dest_user) VALUES ('"+self.uui.selfOwner_CMB.currentText()+"','"+a_new_user+"')")
        self.conn.commit()

        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Information)
        msgBox.setText('تغییرات با موفقیت ذخیره شد')
        msgBox.setWindowTitle("موفقیت")
        msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
        msgBox.exec_()

    def sourceUserChanged(self):
        self.fillSelectedUsers() 
     
    def create_project_clicked(self):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Information)

        cursor = self.conn.cursor()

        proj_name = self.cpui.projName_LE.text().strip()
        contract_no = self.cpui.contractNumber_LE.text().strip()
        applicant = self.cpui.applicant_LE.text().strip()
        adviser = self.cpui.adviser_LE.text().strip()
        proj_type = self.cpui.projClass_CMB.currentText().strip()
        equipment = self.cpui.equipment_CMB.currentText().strip()

        if proj_name == '' or proj_type == '' or equipment == '':
            msgBox.setText('نام، نوع و تجهیزات برداشت پروژه نمی تواند خالی باشد')
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
            return

        query = "INSERT INTO cartable.project(project_name, status, cont_no, requester, contractor, change_type, coll_instr) VALUES ('%s', '%s'%s, '%s', '%s', '%s', '%s'%s, '%s'%s);"%(proj_name,'باز','::cartable.project_status', 'null' if len(contract_no) == 0 else  contract_no,'null' if len(applicant) == 0 else  applicant,'null' if len(adviser) == 0 else  adviser,'null' if len(proj_type) == 0 else  proj_type,'' if len(proj_type) == 0 else '::cartable.change_type','null' if len(equipment) == 0 else  equipment,'' if len(equipment) == 0 else '::cartable.coll_instr')
        query = query.replace("'null'","null")
        cursor.execute(query)
        self.conn.commit()
        msgBox.setText('پروژه با موفقیت ثبت شد.')
        msgBox.setWindowTitle("موفق")
        msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
        msgBox.exec_()

    def is_admin(self):
        username = self.dbconn.getUsername()
        cursor = self.conn.cursor()
        cursor.execute("SELECT EXISTS (select * from app_role where role = '"+ username +"' AND app_access_id IN (SELECT access_id::INTEGER FROM app_access WHERE code = 'cartable_admin'))")
        recs = cursor.fetchall()
        if recs[0][0] == True:
            return True
        else:
            return False
        self.conn.close()

    def fill_changable_projects_window(self,is_cartable):
        self.cui.details_Table.setRowCount(0)
        if is_cartable: 
            user_query = 'TRUE'
        else:
            user_query = 'FALSE'

        query = "select * from cartable.cartable_projs('"+self.dbconn.getUsername()+"',"+user_query+") as (smid int, project_name text, cont_no text, requester text, contractor text, change_type text,coll_instr text,status text, creator text, current_responsible text,  time_created timestamp, last_change timestamp);"

        cursor = self.conn.cursor()
        cursor.execute(query)
        records = cursor.fetchall()
        for row in records:
            proj_smid = str(row[0])
            if is_cartable:
                cursor1 = self.conn.cursor()
                cursor1.execute('SELECT cartable.project_seen(' + proj_smid +')')

            rows = self.cui.details_Table.rowCount()
            self.cui.details_Table.setRowCount(rows + 1)

            self.cui.details_Table.setItem(rows, 0, QTableWidgetItem(proj_smid)) # smid
            self.cui.details_Table.setItem(rows, 1, QTableWidgetItem(str(row[1]))) # project_name
            self.cui.details_Table.setItem(rows, 2, QTableWidgetItem(str(row[2] if row[2] is not None else ''))) # cont_no
            self.cui.details_Table.setItem(rows, 3, QTableWidgetItem(str(row[3] if row[3] is not None else ''))) # requester
            self.cui.details_Table.setItem(rows, 4, QTableWidgetItem(str(row[4] if row[4] is not None else ''))) # addvisor
            self.cui.details_Table.setItem(rows, 5, QTableWidgetItem(str(row[5] if row[5] is not None else ''))) # proj_type
            self.cui.details_Table.setItem(rows, 6, QTableWidgetItem(str(row[6] if row[6] is not None else ''))) # coll_instr
            self.cui.details_Table.setItem(rows, 7, QTableWidgetItem(str(row[7]))) # status
            self.cui.details_Table.setItem(rows, 8, QTableWidgetItem(str(row[8]))) # creator
            self.cui.details_Table.setItem(rows, 9, QTableWidgetItem(str(row[9]))) # current_responsible

            geog_date = row[10].strftime("%x")
            geog_time = row[10].strftime("%H:%M:%S")
            geog_date_part = geog_date.split('/')
            jal_date = Jalaali.to_jalaali(int('20'+geog_date_part[2]),int(geog_date_part[0]),int(geog_date_part[1]))
            jal_date_ready = str(jal_date['jy'])+'/'+str(jal_date['jm'])+'/'+str(jal_date['jd']) + ' ' + geog_time
            self.cui.details_Table.setItem(rows, 10, QTableWidgetItem(jal_date_ready)) # time_created

            geog_date = row[11].strftime("%x")
            geog_time = row[11].strftime("%H:%M:%S")
            geog_date_part = geog_date.split('/')
            jal_date = Jalaali.to_jalaali(int('20'+geog_date_part[2]),int(geog_date_part[0]),int(geog_date_part[1]))
            jal_date_ready = str(jal_date['jy'])+'/'+str(jal_date['jm'])+'/'+str(jal_date['jd']) + ' ' + geog_time
            self.cui.details_Table.setItem(rows, 11, QTableWidgetItem(str(jal_date_ready))) # last_change

        self.conn.commit()
            
    def cartable_st_change(self):
        if self.cui.cartable_CHB.isChecked():
            self.fill_changable_projects_window(True)
        else:
            self.fill_changable_projects_window(False)
        
    def generateMenu(self, pos):
        self.menu.exec_(self.cui.details_Table.mapToGlobal(pos))
    
    def updFgenerateMenu(self , pos):
        self.updF_menu.exec_(self.pF.upd_Features_TBL.mapToGlobal(pos))
    
    def insFgenerateMenu(self , pos):
        self.insF_menu.exec_(self.pF.ins_Features_TBL.mapToGlobal(pos))

    def delFgenerateMenu(self , pos):
        self.delF_menu.exec_(self.pF.del_Features_TBL.mapToGlobal(pos))

    def insgenerateMenu(self , pos):
        self.ins_menu.exec_(self.pF.ins_tableName_TBL.mapToGlobal(pos))

    def updgenerateMenu(self , pos):
        self.upd_menu.exec_(self.pF.upd_tableName_TBL.mapToGlobal(pos))

    def delgenerateMenu(self , pos):
        self.del_menu.exec_(self.pF.del_tableName_TBL.mapToGlobal(pos))

    def eventFilter(self, source, event):
        if (event.type() == QtCore.QEvent.MouseButtonPress and event.buttons() == QtCore.Qt.RightButton):
            if source is self.cui.details_Table.viewport():
                item = self.cui.details_Table.itemAt(event.pos())
                if item is None:
                    self.menu = QtWidgets.QMenu(self)
                    self.menu.addAction('آخه چرا اینجا؟', self.nothing)
                    return super(CreateProGUI, self).eventFilter(source, event)
                owner = self.cui.details_Table.item(item.row(), 9).text() # age ijad konande bud 8 agar karbare jari bud 9
                status = self.cui.details_Table.item(item.row(), 7).text()
                if item is not None:
                    if owner == self.dbconn.getUsername():
                        self.menu = QtWidgets.QMenu(self)
                        # self.menu = QtWidgets.QMenu(self)
                        self.menu.addAction('حذف', self.delete)
                        self.menu.addAction('ارسال', self.send)
                        self.menu.addAction('نمایش بر روی نقشه', lambda: self.showInMap('all'))
                        self.menu.addAction('مشاهده گردش کار', self.workflow)
                        self.menu.addAction('تغییر وضعیت', self.edit)
                        self.menu.addAction('عوارض پروژه',self.proj_feats)
                        if self.is_admin():
                            self.menu.addAction('انتقال به پایگاه اصلی',self.transform)
                    else:
                        self.menu = QtWidgets.QMenu(self)
                        self.menu.addAction('مشاهده گردش کار', self.workflow)
                        cursor = self.conn.cursor()
                        cursor.execute('SELECT status FROM cartable.project WHERE smid = ' + self.cui.details_Table.selectedItems()[0].text())
                        if cursor.fetchone()[0] != 'منتقل شده':
                            self.menu.addAction('نمایش بر روی نقشه', lambda: self.showInMap('all'))
                            self.menu.addAction('انتقال به پایگاه داده اصلی', self.sendToGis) # in koja mikhad seda zade she ????
                        #age owner khodesh nabud chia ro neshun bede

            elif source is self.pF.upd_Features_TBL.viewport():
                self.updF_menu = QtWidgets.QMenu(self)
                tbl_name = self.getEngNameOfTable(self.pF.upd_tableName_TBL.selectedItems()[0].text())
                layer = self.findLayer('cartable',tbl_name)
                if 'smgeometry' in layer.source():
                    self.updF_menu.addAction('انتخاب و برو به', lambda: self.showInMap('UPD_single'))

            elif source is self.pF.ins_Features_TBL.viewport():
                self.insF_menu = QtWidgets.QMenu(self)
                tbl_name = self.getEngNameOfTable(self.pF.ins_tableName_TBL.selectedItems()[0].text())
                layer = self.findLayer('cartable',tbl_name)
                if 'smgeometry' in layer.source():
                    self.insF_menu.addAction('انتخاب و برو به', lambda: self.showInMap('INS_single'))

            elif source is self.pF.del_Features_TBL.viewport():
                self.delF_menu = QtWidgets.QMenu(self)
                tbl_name = self.getEngNameOfTable(self.pF.del_tableName_TBL.selectedItems()[0].text())
                print(tbl_name)
                layer = self.findLayer('public',tbl_name)
                print(layer)
                if 'smgeometry' in layer.source():
                    self.delF_menu.addAction('انتخاب و برو به', lambda: self.showInMap('DEL_single'))

            elif source is self.pF.ins_tableName_TBL.viewport():
                self.ins_menu = QtWidgets.QMenu(self)
                tbl_name = self.getEngNameOfTable(self.pF.ins_tableName_TBL.selectedItems()[0].text())
                layer = self.findLayer('cartable',tbl_name)
                if 'smgeometry' in layer.source():
                    self.ins_menu.addAction('انتخاب و برو به', lambda: self.showInMap('INS'))

            elif source is self.pF.upd_tableName_TBL.viewport():
                self.upd_menu = QtWidgets.QMenu(self)
                tbl_name = self.getEngNameOfTable(self.pF.upd_tableName_TBL.selectedItems()[0].text())
                layer = self.findLayer('cartable',tbl_name)
                if 'smgeometry' in layer.source():
                    self.upd_menu.addAction('انتخاب و برو به', lambda: self.showInMap('UPD'))
            
            elif source is self.pF.del_tableName_TBL.viewport():
                self.del_menu = QtWidgets.QMenu(self)
                tbl_name = self.getEngNameOfTable(self.pF.del_tableName_TBL.selectedItems()[0].text())
                layer = self.findLayer('public',tbl_name)
                if 'smgeometry' in layer.source():
                    self.del_menu.addAction('انتخاب و برو به', lambda: self.showInMap('DEL'))

        return super(CreateProGUI, self).eventFilter(source, event)

    def nothing(self):
        pass

    def delete(self):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Warning)
        msgBox.setText('آیا از حذف پروژه مطمئن هستید؟')
        msgBox.setWindowTitle("هشدار")
        msgBox.addButton(QtWidgets.QPushButton("بله"), QtWidgets.QMessageBox.YesRole)
        msgBox.addButton(QtWidgets.QPushButton("خیر"), QtWidgets.QMessageBox.NoRole)
        returnValue = msgBox.exec_()
        if returnValue == 0:
            cursor = self.conn.cursor()
            project_smid = self.cui.details_Table.selectedItems()[0].text()
            query = "UPDATE cartable.project SET status = 'باز' WHERE smid = "+project_smid+"; DELETE FROM cartable.project_features WHERE project_id =" + project_smid +"; DELETE FROM cartable.project WHERE smid = " + project_smid
            cursor.execute(query)
            self.conn.commit()
            self.cartable_st_change()
        else:
            pass

    def transform(self):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Warning)
        msgBox.setText('آیا از انتقال پروژه به پایگاه داده اصلی مطمئن هستید؟ این تغییر غیرقابل برگشت است.')
        msgBox.setWindowTitle("هشدار")
        msgBox.addButton(QtWidgets.QPushButton("بله"), QtWidgets.QMessageBox.YesRole)
        msgBox.addButton(QtWidgets.QPushButton("خیر"), QtWidgets.QMessageBox.NoRole)
        returnValue = msgBox.exec_()
        if returnValue == 0:
            cursor = self.conn.cursor()
            project_smid = self.cui.details_Table.selectedItems()[0].text()
            query = "SELECT cartable.transform_to_gis("+project_smid+")"
            cursor.execute(query)
            self.conn.commit()
        self.fill_changable_projects_window(True)
        
    def showInMap(self, par):
        cursor = self.conn.cursor()
        if par == 'all':
            print('SELECT cartable.get_project_bb('+ self.cui.details_Table.selectedItems()[0].text() +')')
            cursor.execute('SELECT cartable.get_project_bb('+ self.cui.details_Table.selectedItems()[0].text() +')')
            records = cursor.fetchall()
            if records[0][0] is None:
                msgBox = QtWidgets.QMessageBox()
                msgBox.setIcon(QtWidgets.QMessageBox.Warning)
                msgBox.setText('این پروژه عارضه ای ندارد')
                msgBox.setWindowTitle("هشدار")
                msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
                returnValue = msgBox.exec_()
                return
            parts = records[0][0].split(' ')
            bb = QgsRectangle(float(parts[0]), float(parts[1]), float(parts[2]), float(parts[3]))
            self.conn.commit()
            canvas = iface.mapCanvas()
            canvas.setExtent(bb)
            canvas.refresh()
            return
        elif par == 'INS_single':
            tbl_name = self.getEngNameOfTable(self.pF.ins_tableName_TBL.selectedItems()[0].text())
            ids_to_select = [int(self.pF.ins_Features_TBL.selectedItems()[0].text())]
            layer = self.findLayer('cartable',tbl_name)
        elif par == 'UPD_single':
            tbl_name = self.getEngNameOfTable(self.pF.upd_tableName_TBL.selectedItems()[0].text())
            ids_to_select = [int(self.pF.upd_Features_TBL.selectedItems()[0].text())]
            layer = self.findLayer('cartable',tbl_name)
        elif par == 'DEL_single':
            tbl_name = self.getEngNameOfTable(self.pF.del_tableName_TBL.selectedItems()[0].text())
            ids_to_select = [int(self.pF.del_Features_TBL.selectedItems()[0].text())]
            layer = self.findLayer('public',tbl_name)
        elif par == 'INS':
            tbl_name = self.getEngNameOfTable(self.pF.ins_tableName_TBL.selectedItems()[0].text())
            layer = self.findLayer('cartable',tbl_name)
            proj_id = self.cui.details_Table.selectedItems()[0].text()
            cursor = self.conn.cursor()
            cursor.execute("select feature_smid from cartable.project_features WHERE class_name = '"+tbl_name+"' AND project_id = "+proj_id+" AND feature_transaction = 'درج'")
            ids_to_select = []
            for a_smid in cursor.fetchall():
                ids_to_select.append(a_smid[0])
        elif par == 'UPD':
            tbl_name = self.getEngNameOfTable(self.pF.upd_tableName_TBL.selectedItems()[0].text())
            layer = self.findLayer('cartable',tbl_name)
            proj_id = self.cui.details_Table.selectedItems()[0].text()
            cursor = self.conn.cursor()
            cursor.execute("select feature_smid from cartable.project_features WHERE class_name = '"+tbl_name+"' AND project_id = "+proj_id+" AND feature_transaction = 'تغییر'")
            ids_to_select = []
            for a_smid in cursor.fetchall():
                ids_to_select.append(a_smid[0])
        elif par == 'DEL':
            tbl_name = self.getEngNameOfTable(self.pF.del_tableName_TBL.selectedItems()[0].text())
            layer = self.findLayer('public',tbl_name)
            proj_id = self.cui.details_Table.selectedItems()[0].text()
            cursor = self.conn.cursor()
            cursor.execute("select feature_smid from cartable.project_features WHERE class_name = '"+tbl_name+"' AND project_id = "+proj_id+" AND feature_transaction = 'حذف'")
            ids_to_select = []
            for a_smid in cursor.fetchall():
                ids_to_select.append(a_smid[0])

        layer.selectByIds(ids_to_select)
        box = layer.boundingBoxOfSelected()
        box.grow(10)
        iface.mapCanvas().setExtent(box)
        iface.mapCanvas().refresh()

    def workflow(self):
        self.initWorkFlowUI()
    
    def edit(self):
        project_smid = self.cui.details_Table.selectedItems()[0].text()
        project_status = self.cui.details_Table.selectedItems()[7].text()
        cursor = self.conn.cursor()
        if project_status == 'بسته':
            cursor.execute("select exists(select * from cartable.project where current_responsible = '"+self.dbconn.getUsername()+"' and status = 'باز' AND smid <> "+ project_smid +")")
            if cursor.fetchone()[0] == True:
                iface.messageBar().pushMessage("Warning", "شما یک پروژه باز دارید و نمی توانید این پروژه را باز کنید. ابتدا پروژه باز خود را ببندید",level = Qgis.Warning, duration = 5) 
                return
        iface.messageBar().pushMessage("Info", "تغییر وضعیت پروژه انجام شد",level = Qgis.Info, duration = 5) 
        cursor.execute("SELECT cartable.change_proj_status(" + project_smid + ')')
        self.conn.commit()
        self.fill_changable_projects_window(True)

    def proj_feats(self):
        # Get the number of each operation and each table 
        self.initProjectFeaturesUI()
        project_smid = self.cui.details_Table.selectedItems()[0].text()
        cursor = self.conn.cursor()
        query = "select smregister.smtablename, R.feature_transaction, num from (select class_name, feature_transaction, count(*) as num FROM cartable.project_features WHERE project_id = " + project_smid + " group by class_name, feature_transaction) R inner join smregister ON R.class_name = smregister.smdatasetname ORDER BY smregister.smtablename" 
        cursor.execute(query)
        for a_rec in cursor.fetchall():
            if a_rec[1] == 'درج':
                rows = self.pF.ins_tableName_TBL.rowCount()
                self.pF.ins_tableName_TBL.setRowCount(rows + 1)
                self.pF.ins_tableName_TBL.setItem(rows, 0, QTableWidgetItem(a_rec[0])) # class_name in Persian
                self.pF.ins_tableName_TBL.setItem(rows, 1, QTableWidgetItem(str(a_rec[2]))) # number of records
            elif a_rec[1] == 'تغییر':
                rows = self.pF.upd_tableName_TBL.rowCount()
                self.pF.upd_tableName_TBL.setRowCount(rows + 1)
                self.pF.upd_tableName_TBL.setItem(rows, 0, QTableWidgetItem(a_rec[0])) # class_name in Persian
                self.pF.upd_tableName_TBL.setItem(rows, 1, QTableWidgetItem(str(a_rec[2]))) # number of records
            else:
                rows = self.pF.del_tableName_TBL.rowCount()
                self.pF.del_tableName_TBL.setRowCount(rows + 1)
                self.pF.del_tableName_TBL.setItem(rows, 0, QTableWidgetItem(a_rec[0])) # class_name in Persian
                self.pF.del_tableName_TBL.setItem(rows, 1, QTableWidgetItem(str(a_rec[2]))) # number of records
        self.conn.commit()
        self.pF.ins_tableName_TBL.resizeColumnsToContents()
        self.pF.upd_tableName_TBL.resizeColumnsToContents()
        self.pF.del_tableName_TBL.resizeColumnsToContents()
    
    def ins_tab_clicked(self):
        self.pF.ins_Features_TBL.clear()
        tbl_name = self.pF.ins_tableName_TBL.selectedItems()[0].text()
        project_smid = self.cui.details_Table.selectedItems()[0].text()
        en_tbl_name = self.getEngNameOfTable(tbl_name)
        query_tran = "select field_en, field_fa from translate_table_fields where table_en = '"+en_tbl_name+"'"
        query_cols = "select column_name from information_schema.columns where table_schema = 'cartable' and table_name = '"+en_tbl_name+"' AND column_name <> 'smgeometry' ORDER BY ordinal_position"
        query_data = "SELECT * FROM cartable."+en_tbl_name+" WHERE smid IN (select feature_smid from cartable.project_features where project_id = "+project_smid+" AND class_name = '"+en_tbl_name+"' AND feature_transaction = 'درج')"
        cursor = self.conn.cursor()
        cursor.execute(query_cols)
        cols = []
        for a_rec in cursor.fetchall():
            cols.append(a_rec[0])
        trans = dict()
        cursor.execute(query_tran)
        for a_rec in cursor.fetchall():
            trans[a_rec[0]] = a_rec[1]
        cursor = self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute(query_data)
        recs = cursor.fetchall()
        self.pF.ins_Features_TBL.setRowCount(len(recs))
        row = 0
        for a_rec in recs:
            col = 0
            for a_col in cols:
                if a_col in trans:
                    print(a_col , ' ',a_rec[a_col])
                    if row == 0:
                        self.pF.ins_Features_TBL.setColumnCount(len(trans))
                        self.pF.ins_Features_TBL.setHorizontalHeaderItem(col,QtWidgets.QTableWidgetItem(trans[a_col]))
                    self.pF.ins_Features_TBL.setItem(row, col, QtWidgets.QTableWidgetItem(str(a_rec[a_col])))
                    col += 1
            row += 1
        self.pF.ins_Features_TBL.resizeColumnsToContents()

    def upd_tab_clicked(self):
        self.pF.upd_Features_TBL.clear()
        tbl_name = self.pF.upd_tableName_TBL.selectedItems()[0].text()
        project_smid = self.cui.details_Table.selectedItems()[0].text()
        en_tbl_name = self.getEngNameOfTable(tbl_name)
        query_tran = "select field_en, field_fa from translate_table_fields where table_en = '"+en_tbl_name+"'"
        query_cols = "select column_name from information_schema.columns where table_schema = 'cartable' and table_name = '"+en_tbl_name+"' AND column_name <> 'smgeometry' ORDER BY ordinal_position"
        query_data = "SELECT * FROM cartable."+en_tbl_name+" WHERE smid IN (select feature_smid from cartable.project_features where project_id = "+project_smid+" AND class_name = '"+en_tbl_name+"' AND feature_transaction = 'تغییر')"
        cursor = self.conn.cursor()
        cursor.execute(query_cols)
        cols = []
        for a_rec in cursor.fetchall():
            cols.append(a_rec[0])
        trans = dict()
        cursor.execute(query_tran)
        for a_rec in cursor.fetchall():
            trans[a_rec[0]] = a_rec[1]
        cursor = self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute(query_data)
        recs = cursor.fetchall()
        self.pF.upd_Features_TBL.setRowCount(len(recs))
        row = 0
        for a_rec in recs:
            col = 0
            for a_col in cols:
                if a_col in trans:
                    if row == 0:
                        self.pF.upd_Features_TBL.setColumnCount(len(trans))
                        self.pF.upd_Features_TBL.setHorizontalHeaderItem(col,QtWidgets.QTableWidgetItem(trans[a_col]))
                    self.pF.upd_Features_TBL.setItem(row, col, QtWidgets.QTableWidgetItem(str(a_rec[a_col])))
                    col += 1
            row += 1
        self.pF.upd_Features_TBL.resizeColumnsToContents()

    def del_tab_clicked(self):
        self.pF.del_Features_TBL.clear()
        tbl_name = self.pF.del_tableName_TBL.selectedItems()[0].text()
        project_smid = self.cui.details_Table.selectedItems()[0].text()
        en_tbl_name = self.getEngNameOfTable(tbl_name)
        query_tran = "select field_en, field_fa from translate_table_fields where table_en = '"+en_tbl_name+"'"
        query_cols = "select column_name from information_schema.columns where table_schema = 'cartable' and table_name = '"+en_tbl_name+"' AND column_name <> 'smgeometry' ORDER BY ordinal_position"
        query_data = "SELECT * FROM "+en_tbl_name+" WHERE smid IN (select feature_smid from cartable.project_features where project_id = "+project_smid+" AND class_name = '"+en_tbl_name+"' AND feature_transaction = 'حذف')"
        cursor = self.conn.cursor()
        cursor.execute(query_cols)
        cols = []
        for a_rec in cursor.fetchall():
            cols.append(a_rec[0])
        trans = dict()
        cursor.execute(query_tran)
        for a_rec in cursor.fetchall():
            trans[a_rec[0]] = a_rec[1]
        cursor = self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute(query_data)
        recs = cursor.fetchall()
        self.pF.del_Features_TBL.setRowCount(len(recs))
        row = 0
        for a_rec in recs:
            col = 0
            for a_col in cols:
                if a_col in trans:
                    if row == 0:
                        self.pF.del_Features_TBL.setColumnCount(len(trans))
                        self.pF.del_Features_TBL.setHorizontalHeaderItem(col,QtWidgets.QTableWidgetItem(trans[a_col]))
                    self.pF.del_Features_TBL.setItem(row, col, QtWidgets.QTableWidgetItem(str(a_rec[a_col])))
                    col += 1
            row += 1
        self.pF.del_Features_TBL.resizeColumnsToContents()

    def detect_changes(self):
        tbl_name = self.getEngNameOfTable(self.pF.upd_tableName_TBL.selectedItems()[0].text())
        rec_smid = self.pF.upd_Features_TBL.selectedItems()[0].text()
        query = "SELECT cartable.change_detection('"+tbl_name+"'::TEXT,"+rec_smid+")"
        print(query)
        cursor = self.conn.cursor()
        cursor.execute(query)
        self.pF.tableWidget.setRowCount(2)
        rec = cursor.fetchall()[0]
        jrec = json.loads(rec[0])
        self.pF.tableWidget.setColumnCount(len(jrec) + 1)
        col = 0
        self.pF.tableWidget.setHorizontalHeaderItem(0,QtWidgets.QTableWidgetItem('حالت'))
        self.pF.tableWidget.setItem(0, 0, QtWidgets.QTableWidgetItem('قبل'))
        self.pF.tableWidget.setItem(1, 0, QtWidgets.QTableWidgetItem('بعد'))
        for key, value in jrec.items():
            print(key, ' ',value[0], ' ',value[1])
            col += 1
            self.pF.tableWidget.setHorizontalHeaderItem(col,QtWidgets.QTableWidgetItem(key))
            self.pF.tableWidget.setItem(0, col, QtWidgets.QTableWidgetItem(str(value[0])))
            self.pF.tableWidget.setItem(1, col, QtWidgets.QTableWidgetItem(str(value[1])))
        self.pF.tableWidget.resizeColumnsToContents()

    def getEngNameOfTable(self, perName):
        cursor = self.conn.cursor()
        cursor.execute("""
                SELECT
                    smdatasetname
                FROM
                    public.smregister
                WHERE
                    smtablename = %s
            """, (perName,))
        data = cursor.fetchone()
        if data:
            smdatasetname = data[0]
        else:
            smdatasetname = None
        return smdatasetname

    def findLayer(self,schema_name,layer_name):
        print('iside findlayer')
        layers = QgsProject.instance().mapLayers()
        for layer_id, layer in layers.items():
            print(layer)
            if '"'+schema_name+'"."'+layer_name+'"' in layer.source():
                print('found: ',layer)
                return layer

    def send(self):
        self.initDescriptionUI()

    def runCreateProWindow(self):
        self.run()
        self.initCreateProjectUI()
        self.show()

    def runListOfProjectWindow(self):
        self.run()
        self.initListOfProjectUI()
        self.show()

    def runCartableUIWindow(self):
        self.run()
        self.initCartableUI()
        self.show()
        
    def runUserWindow(self):
        self.run()
        self.initUserWindow()
        self.show()
        
    def run(self):
        usePlugin = UsePlugin()

        if not usePlugin.checkAll():
            return

        dBConnection = DBConnection(
            usePlugin.projVals['host'],
            usePlugin.projVals['port'],
            usePlugin.projVals['dbname'])

        self.dbconn = dBConnection
        self.conn = self.dbconn.getConn()
        
        print(self.dbconn.getUsername())

def main():
    app = QtWidgets.QApplication(sys.argv)
    ex = CreateProGUI()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()