import qgis
from qgis import utils
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.gui import QgsLayerTreeViewMenuProvider
from qgis.PyQt.QtWidgets import QAction, QMenu
import pyplugin_installer
import subprocess
import sys, os, os.path
import configparser
from PyQt5 import QtWidgets, QtGui, uic, QtCore
import psycopg2
from psycopg2 import sql
from qgis.utils import iface
from .DataAccess import *
#===========================================================


class DbConn_QGIS:

    loginData = qgis.core.QgsDataSourceUri()
    conn = None

    def __init__(self, host, port, dbName):
        self.loginData.setConnection(host, port, dbName, None, None, 1)

    def __del__(self):
        self.closeConn()

    def getConnIfValid(self, username, password):
        try:
            conn = psycopg2.connect(user = username,
                                  password = password,
                                  host = self.loginData.host(),
                                  port = self.loginData.port(),
                                  dbname = self.loginData.database())
            return conn
        except Exception as e:
            print(e)
            return False

    # return connection if success; else None.
    def getConn(self):
        if (not self.conn):
            connInfo = self.loginData.connectionInfo()
            inUser = None
            inPass = None
            success = True
            while (success):
                (success, inUser, inPass) = qgis.core.QgsCredentials.instance().get(connInfo, inUser, inPass)
                conn = self.getConnIfValid(inUser, inPass)
                if (conn):
                    qgis.core.QgsCredentials.instance().put(connInfo, inUser, inPass)
                    self.validData = True
                    self.loginData.setUsername(inUser)
                    self.loginData.setPassword(inPass)
                    self.conn = conn
                    break
        return self.conn

    # return username if a valid one entered. None otherwise.
    def getUsername(self):
        return self.loginData.username()
        
    def getHost(self):
        return self.loginData.host()
        
    def getPass(self):
        return self.loginData.password()
        
    def closeConn(self):
        if (self.conn):
            self.conn.close()
            self.conn = None


class DbConn_ConfFile:

    conf = {}

    def __init__(self):
        self.updateConf()

    # Get a connection to the database.
    def getConn(self):
        try:
            conn = psycopg2.connect(user = self.conf['DB_user'],
                            password = self.conf['DB_pass'],
                            host = self.conf['DB_host'],
                            port = self.conf['DB_port'],
                            dbname = self.conf['main_db'])
            conn.autocommit = True
            return conn
        except Exception as e:
            return False

    # Set self.conf.
    def setConf(self):

        self.conf['mainPath'] = getAppDir()
        self.conf['confFilePath'] = self.conf['mainPath'] + '\\main.conf'
        self.conf['logPath'] = self.conf['mainPath'] + '\\main.log'

        confFile = configparser.ConfigParser()
        confFile.read(self.conf['confFilePath'])
        self.conf['fileLogging'] = confFile.getboolean('Main', 'file_logging')
        self.conf['DB_host'] = confFile['DB']['host']
        self.conf['DB_port'] = confFile['DB']['port']
        self.conf['DB_user'] = confFile['DB']['user']
        self.conf['DB_pass'] = confFile['DB']['pass']
        self.conf['main_db'] = confFile['DB']['main_db']
        self.conf['icon_name'] = confFile['Main']['iconName']


    def getQGISConnection(self):
        
        self.conf['mainPath'] = getAppDir()
        self.conf['confFilePath'] = self.conf['mainPath'] + '\\main.conf'
        self.conf['logPath'] = self.conf['mainPath'] + '\\main.log'
        confFile = configparser.ConfigParser()
        confFile.read(self.conf['confFilePath'])
        self.conf['fileLogging'] = confFile.getboolean('Main', 'file_logging')

        user_details = qgis.core.QgsDataSourceUri()        
        self.conf['DB_host'] = user_details.host()
        self.conf['main_db'] = user_details.database()
        self.conf['DB_port'] = user_details.port()
        self.conf['DB_user'] = user_details.username() 
        self.conf['DB_pass'] = user_details.password()  
        
    def updateConf(self):
        self.setConf()
        # self.getQGISConnection()


# Get path of application directory.
def getAppDir():

    # Determine if application is a script file or frozen exe
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    elif __file__:
        application_path = os.path.dirname(__file__)

    application_path = application_path.replace('\\', '/')

    return application_path


class UsePlugin:

    pluginName = None
    updateChecked = False
    projVals = {}
    isReady = False

    def __init__(self):
        dirName = os.path.basename(getAppDir())
        self.pluginName = dirName


    def update(self, force = False):
        if force or not self.updateChecked:
            pyplugin_installer.instance().fetchAvailablePlugins(False)
            pyplugin_installer.instance().upgradeAllUpgradeable()
            self.updateChecked = True
            # mypluginInstance = utils.plugins[self.pluginName]
            # mypluginInstance.run()
            # mypluginInstance.initComp()
            return True
        else:
            return False


    def projVariables(self):
        variables = {}
        project = qgis.core.QgsProject.instance()
        variables['host'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('host')
        variables['dbname'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('dbname')
        variables['port'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('port')        
        variables['version'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('version')
        variables['url_port'] = qgis.core.QgsExpressionContextUtils.projectScope(project).variable('url_port')
        if variables['url_port'] is None:
            variables['url_port'] = '80'
        if None in variables.values():
            return False
        return variables


    def checkProjVariables(self):

        projVals = self.projVariables()
        self.projVals = projVals

        if not projVals:
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            msg = "متغیر های پروژه به درستی تنظیم نشده اند."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
            return False
        else:
            return projVals


    def getDbConnection(self):
        dBConnection = DbConn_QGIS(
            self.getValue('db_host'),
            self.getValue('port'),
            self.getValue('dbname'))
        conn = dBConnection.getConn()
        return dBConnection


    def isUserAllowed(self):

        dBConnection = self.getDbConnection()
        dataAccess = DataAccess(dBConnection)
        
        if dBConnection.getUsername():
            if dBConnection.getUsername() in [ 'serveradmin', 'postgres', 'rassam' ]:
                return True
            if dataAccess.roleInPluginAccess(dBConnection.getUsername(), self.pluginName):
                return True
        return False


    def removeExport(self):

        global ltv, mp, cm
        ltv = iface.layerTreeView()
        mp = ltv.menuProvider()
        cm = mp.createContextMenu()

        actions = cm.actions()
        for action in actions:
            if action.text() == "Export":
                cm.removeAction(action)

        provider = CustomMenuProvider(ltv, cm.actions())
        ltv.setMenuProvider(provider)


    def canExport(self):
        dBConnection = self.getDbConnection()
        conn = dBConnection.getConn()
        dataAccess = DataAccess(dBConnection)

        if dBConnection.getUsername():
            if dBConnection.getUsername() in [ 'serveradmin', 'postgres', 'rassam' ]:
                return True
            elif 'table_export' in dataAccess.getUserAccess(dBConnection.getUsername()):
                return True
        self.removeExport()
        

    def checkUserAllowed(self):
        if not self.isUserAllowed():
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            msg = "شما اجازه دسترسی به این پلاگین را ندارید."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
            return False
        else:
            return True


    # Edit this according to your needs:
    def checkAll(self):
        
        if self.update():
            return False
        
        if not self.checkProjVariables():
            return False
        
        # if not self.checkUserAllowed():
        #     return False

        # self.canExport() # ERROR

        self.isReady = True
        return True


    def getValue(self, name):
        if name == 'qgis_proj':
            return 'http://' + self.projVals['host'] + ':' + self.projVals['url_port']+ '/QGIS_Proj/'
        elif name == 'db_host':
            return self.projVals['host']
        elif name == 'dbname':
            return self.projVals['dbname']
        elif name == 'port':
            return self.projVals['port']
        elif name == 'version':
            return self.projVals['version']
        elif name == 'rep_addr':
            return 'http://' + self.projVals['host'] + ':' + self.projVals['url_port'] + '/plugins/'
            


class CustomMenuProvider(QgsLayerTreeViewMenuProvider):

  def __init__(self, view, actions):
    QgsLayerTreeViewMenuProvider.__init__(self)
    self.view = view
    self.defaultActions = actions

  def createContextMenu(self):
    if not self.view.currentLayer():
      return None
    m = QMenu()
    m.addActions(self.defaultActions)
    return m
