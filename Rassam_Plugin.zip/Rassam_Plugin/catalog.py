import logging
import sys, os, os.path
import datetime, time
from .DataAccess import *
from .mylib import *
from .rassam import *
import xml.etree.ElementTree as ET
from .resources import *
from .catalog_gui import *
from PyQt5 import QtWidgets, QtGui, uic, QtCore


class Catalog(QtWidgets.QMainWindow):

    dataAccess = None
    dbConn = None


    def __init__(self):
        super().__init__()
        self.dbConn = DbConn_ConfFile()
        print("dbconnection"  , self.dbConn)
        self.dataAccess = DataAccess(self.dbConn)
        self.initUI()


    def initUI(self):

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setFixedSize(self.size())
        self.setWindowIcon(QtGui.QIcon(getAppDir() + '/gui/icons/catalog.png'))

        self.statusLabel = QtWidgets.QLabel('')
        self.statusLabel.setAlignment(QtCore.Qt.AlignRight)
        self.ui.statusbar.addWidget(self.statusLabel)

        self.show()
        self.listFields()
        self.ui.catalogName.currentIndexChanged.connect(self.listCols)
        self.ui.searchField.currentIndexChanged.connect(self.searchFieldChanged)
        self.ui.searchValue.textChanged.connect(self.searchNew)


    # Send a message to the user.
    def msgUser(self, type, msg = None):
        self.statusLabel.setText('')
        if type == 'success':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Information)
            if not msg:
                msg = "عملیات با موفقیت انجام شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("موفقیت")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'fail':
            msgBox = QtWidgets.QMessageBox()
            msgBox.setIcon(QtWidgets.QMessageBox.Critical)
            if not msg:
                msg = "عملیات با شکست مواجه شد."
            msgBox.setText(msg)
            msgBox.setWindowTitle("شکست")
            msgBox.addButton(QtWidgets.QPushButton("باشد"), QtWidgets.QMessageBox.YesRole)
            msgBox.exec_()
        elif type == 'wait':
            self.statusLabel.setText('لطفا صبر کنید ...')
            self.statusLabel.setStyleSheet('color: rgb(60, 60, 60)')
        elif type == 'none':
            pass
        QtWidgets.qApp.processEvents()


    def listFields(self):

        self.msgUser('wait')

        self.catalog_list = self.dataAccess.getCatalogs()
        for item in self.catalog_list:
            name = item['fa']
            if not name:
                name = item['en']
            self.ui.catalogName.addItem(name)

        self.msgUser('none')


    def listCols(self):

        self.msgUser('wait')

        self.ui.searchField.setEnabled(False)
        self.ui.searchField.clear()
        self.ui.searchField.addItem('')
        self.ui.searchValue.setEnabled(False)
        self.ui.searchValue.clear()

        self.ui.mainList.clear()
        self.ui.mainList.setColumnCount(0)
        self.ui.mainList.setRowCount(0)

        ind = self.ui.catalogName.currentIndex()
        if ind == 0:
            return
        ind = ind - 1

        catalogName = self.catalog_list[ind]['en']
        faCols = self.dataAccess.getAllFaCols(catalogName)
        rows = self.dataAccess.getRows(catalogName)

        if rows:
            self.ui.mainList.setColumnCount(len(faCols))
            self.ui.mainList.setRowCount(len(rows))
            self.ui.searchField.setEnabled(True)

        for rowInd,row in enumerate(rows):
            for colInd,(en,fa) in enumerate(faCols.items()):
                if rowInd == 0:
                    self.ui.mainList.setHorizontalHeaderItem(colInd, QtWidgets.QTableWidgetItem(fa))
                    self.ui.searchField.addItem(fa)
                value = row[en]
                if value is None:
                    value = ''
                item = QtWidgets.QTableWidgetItem(str(value))
                item.setFlags(item.flags() & ~QtCore.Qt.ItemIsEditable)
                self.ui.mainList.setItem(rowInd, colInd, item)
        self.ui.mainList.resizeColumnsToContents()

        self.msgUser('none')


    def searchNew(self):
        for row in range(self.ui.mainList.rowCount()):
            if self.ui.searchValue.text() in self.ui.mainList.item(row, self.searchCol).text():
                self.ui.mainList.showRow(row)
            else:
                self.ui.mainList.hideRow(row)


    def searchFieldChanged(self):
        self.ui.searchValue.setEnabled(True)
        self.ui.searchValue.clear()
        for col in range(self.ui.mainList.columnCount()):
            if self.ui.mainList.horizontalHeaderItem(col).text() == self.ui.searchField.currentText():
                self.searchCol = col
                break