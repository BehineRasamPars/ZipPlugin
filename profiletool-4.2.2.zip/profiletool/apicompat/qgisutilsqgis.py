# coding=utf-8

import qgis.utils

# QGis in QGIS version 2 was renamed to Qgis in QGIS version 3 

qgis.utils.Qgis = qgis.utils.QGis