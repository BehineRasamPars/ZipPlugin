# coding=utf-8

import qgis.core

# QGis in QGIS version 2 was renamed to Qgis in QGIS version 3 

qgis.core.Qgis = qgis.core.QGis