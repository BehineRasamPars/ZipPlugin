from xlwt import Workbook, Font, XFStyle, Alignment
import configparser
from ..rassam import getAppDir


style_dict = {}

def config_parser_var():
    conf_path = getAppDir()
    confFilePath = conf_path + '\\ExcelOutSample\\Style.conf'
    confFile = configparser.ConfigParser()
    confFile.read(confFilePath)

    style_dict['nazanin_font'] = confFile['Fonts']['Nazanin']
    style_dict['titr_font'] = confFile['Fonts']['Titr']

    return style_dict

style_dict = config_parser_var()
### fonts config ###
fontna = Font()
fontna.name = style_dict['nazanin_font']
alignment = Alignment()
stylenaz = XFStyle()
stylenaz.font = fontna
stylenaz.alignment = alignment


fontbi = Font()
fontbi.name = style_dict['titr_font']
alignment = Alignment()
alignment.horz = Alignment.HORZ_CENTER_ACROSS_SEL
alignment.vert = Alignment.VERT_CENTER
alignment.wrap = Alignment.WRAP_AT_RIGHT
styletit = XFStyle()
styletit.font = fontbi
styletit.alignment = alignment

def writeToExcel(table_name, result, wb, cursor , SheetNameList):

    # creating dictionary

    query = "select cc.column_name, tt.field_fa from information_schema.columns cc inner join translate_table_fields tt on cc.column_name = tt.field_en where cc.table_name = '"+table_name+"' AND cc.table_schema = 'public' and tt.smdatasetid = (select smdatasetid from smregister where smdatasetname = '"+table_name+"')order by cc.ordinal_position"
    cursor.execute(query)
    trans = {}
    for a_rec in cursor.fetchall():
        trans[a_rec[0]] = a_rec[1]

    ### end dictionary ###

    ### start sheet ###
    k = 1
    cursor.execute(
        f"SELECT smtablename FROM smregister WHERE smdatasetname = '{table_name}'")
    sheetname_res = cursor.fetchall()
        
    sheetname = f'{sheetname_res[0][0]}'
    if len(SheetNameList) >= 1:
        if sheetname in SheetNameList.keys():
            print(sheetname)
            k = SheetNameList[sheetname] + 1 
            sheet = wb.get_sheet(sheetname)

        else:
            sheet = wb.add_sheet(f'{sheetname_res[0][0]}')
            sheet.cols_right_to_left = True
    else:
        sheet = wb.add_sheet(f'{sheetname_res[0][0]}')
        sheet.cols_right_to_left = True

    ### end sheet ###

    for a_rec in result:
        i = 0
        for name in a_rec:
            if name in trans:
                if k == 1:
                    sheet.write(0, i, str(trans[name]), style=styletit)
                sheet.write(k, i, a_rec[name], style=stylenaz)
                i = i+1
        k += 1

    SheetNameList[sheetname] = k
    return SheetNameList

def con_tableids(table_id):
    res = '('
    for a_t in table_id:
        res = res + "'"+str(a_t) + "',"
    res = res[:-1]
    res += ')'
    return res

def checkTables(table_name, table_ids, wb, cursor, cursor1 , SheetNameList):
    query = "SELECT self_id FROM db_joins WHERE class_name = '" + table_name + "'"
    cursor.execute(query)
    self_fld = cursor.fetchone()[0]

    # for table_id in table_ids:

    query = 'SELECT * FROM ' + table_name + " WHERE " + \
        self_fld + " IN " + con_tableids(table_ids)
    cursor1.execute(query)
    table_name_res = cursor1.fetchall()
    SheetNameList = writeToExcel(table_name, table_name_res, wb, cursor , SheetNameList)
    query = "select class_name, class_fld, par_class, self_id from db_joins where par_class = '" + table_name + "'"
    cursor.execute(query)
    other_tables = cursor.fetchall()
    if cursor.rowcount == 0:
        pass
    else:
        for a_table in other_tables:
            class_name = a_table[0]
            class_fld = a_table[1]
            pa = a_table[2]
            selfid = a_table[3]
            # get the list of a_table
            # for a-table we must get id code
            query = 'SELECT ' + selfid + ' FROM ' + class_name + \
                ' WHERE ' + class_fld + " IN " + con_tableids(table_ids)
            cursor.execute(query)
            if cursor.rowcount == 0:
                pass
            else:
                table_ids_res = cursor.fetchall()
                table_ids_res_list = []
                for id in table_ids_res:
                    table_ids_res_list.append(id[0])
                checkTables(class_name, table_ids_res_list,
                            wb, cursor, cursor1 , SheetNameList)

def ContainerFunc(cursor , cursor_extra , table_name , dispach_code , fileName , address):
    wb = Workbook()
    checkTables(table_name,[dispach_code], wb, cursor, cursor_extra , SheetNameList = {})
    wb.save(address+fileName)
    return True