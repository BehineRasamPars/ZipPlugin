import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment
import configparser
from ..rassam import getAppDir

style_dict = {}

def config_parser_var():
    conf_path = getAppDir()
    confFilePath = conf_path + '\\ExcelOutSample\\Style.conf'
    confFile = configparser.ConfigParser()
    confFile.read(confFilePath)

    style_dict['title_color'] = confFile['Color']['Title']
    style_dict['body_color'] = confFile['Color']['Body']
    style_dict['nazanin_font'] = confFile['Fonts']['Nazanin']
    style_dict['titr_font'] = confFile['Fonts']['Titr']

    return style_dict

def rgb_to_hex(rgb):
    return '%02x%02x%02x' % rgb

### write records in xls file ###


def writeToExcel(table_name, result, sheet, cursor, row, col, prev_rec, titr_c, value_c):

    # CoLOR VALUE FOR CELLS
    excel_style_dict = config_parser_var()
    naznanin_font = excel_style_dict['nazanin_font']
    titr_font = excel_style_dict['titr_font']

    first_db_color = eval(titr_c)
    second_db_color = eval(value_c)

    first_hex_color = rgb_to_hex(first_db_color)
    second_hex_color = rgb_to_hex(second_db_color)

    # creating dictionary

    query = "select cc.column_name, tt.field_fa from information_schema.columns cc inner join translate_table_fields tt on cc.column_name = tt.field_en where cc.table_name = '"+table_name+"' AND cc.table_schema = 'public' and tt.smdatasetid = (select smdatasetid from smregister where smdatasetname = '"+table_name+"')order by cc.ordinal_position"
    cursor.execute(query)
    trans = {}
    for a_rec in cursor.fetchall():
        trans[a_rec[0]] = a_rec[1]

    ### end dictionary ###

    cursor.execute(
        f"SELECT smtablename FROM smregister WHERE smdatasetname = '{table_name}'")
    sheetname_res = cursor.fetchall()[0][0]
    sheet.title = "sheet1"

    row_n = row
    for a_rec in result:
        for name in a_rec:
            if name in trans:
                if sheetname_res != prev_rec:
                    if prev_rec is None:
                        sheet.cell(row=row, column=1).value = str(
                            sheetname_res)
                        sheet.cell(row=row, column=1).fill = PatternFill(
                            start_color=first_hex_color, end_color=first_hex_color, fill_type="solid")
                        sheet.cell(row=row, column=1).font = Font(
                            name=titr_font, size=12, bold=False, charset=178)
                        sheet.cell(row=row, column=1).alignment = Alignment(
                            horizontal='center', vertical='center', wrapText=True)
                        # Font(size=23, underline='single', color='FFBB00', bold=True,italic=True)
                        sheet.cell(row=row, column=col +
                                   1).value = str(trans[name])
                        sheet.cell(row=row, column=col+1).fill = PatternFill(
                            start_color=first_hex_color, end_color=first_hex_color, fill_type="solid")
                        sheet.cell(row=row, column=col+1).font = Font(
                            name=titr_font, size=12, bold=False, charset=178)
                        sheet.cell(row=row, column=col+1).alignment = Alignment(
                            horizontal='center', vertical='center', wrapText=True)
                        row_n = row + 1
                        # sheet.write(row, 0, str(sheetname_res), style=stylentitr)
                        # sheet.write(row, col, str(trans[name]), style=styletit)
                        # row_n = row + 1
                    else:
                        sheet.cell(
                            row=row+1, column=1).value = str(sheetname_res)
                        sheet.cell(row=row+1, column=1).fill = PatternFill(
                            start_color=first_hex_color, end_color=first_hex_color, fill_type="solid")
                        sheet.cell(
                            row=row+1, column=1).font = Font(name=titr_font, size=12, bold=False, charset=178)
                        sheet.cell(row=row+1, column=1).alignment = Alignment(
                            horizontal='center', vertical='center', wrapText=True)

                        sheet.cell(row=row+1, column=col +
                                   1).value = str(trans[name])
                        sheet.cell(row=row+1, column=col+1).fill = PatternFill(
                            start_color=first_hex_color, end_color=first_hex_color, fill_type="solid")
                        sheet.cell(row=row+1, column=col+1).font = Font(
                            name=titr_font, size=12, bold=False, charset=178)
                        sheet.cell(row=row+1, column=col+1).alignment = Alignment(
                            horizontal='center', vertical='center', wrapText=True)
                        # sheet.write(row+1, 0, str(sheetname_res), style=stylentitr)
                        # sheet.write(row+1, col, str(trans[name]), style=styletit)
                        row_n = row + 2

                sheet.cell(row=row_n, column=col+1).fill = PatternFill(start_color=second_hex_color, end_color=second_hex_color, fill_type="solid")
                sheet.cell(row=row_n, column=col+1).font = Font(name=naznanin_font,size=10, bold=False, charset=178)
                sheet.cell(row=row_n, column=col+1).alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                sheet.cell(row=row_n, column=col+1).value = a_rec[name]

                col = col+1

                # sheet.write(row_n, col, a_rec[name], style=stylenaz)
                # col = col+1

    return row_n + 1, sheetname_res


def checkTables(table_name, table_id, sheet, cursor, cursor1, row, col, prev_rec, titcolor, valuecolor):
    query = "SELECT self_id FROM db_joins WHERE class_name = '" + table_name + "'"
    cursor.execute(query)
    self_fld = cursor.fetchone()[0]

    query = 'SELECT * FROM ' + table_name + " WHERE " + self_fld + " = '" + table_id + "'"
    cursor1.execute(query)
    table_name_res = cursor1.fetchall()
    row, prev_rec = writeToExcel(table_name, table_name_res, sheet, cursor, row, col, prev_rec, titcolor, valuecolor)
    # return
    query = "select class_name, class_fld, par_class, self_id,titr_color,value_color from db_joins where par_class = '" + table_name + "'"
    cursor.execute(query)
    child_table = cursor.fetchall()
    if cursor.rowcount == 0:
        pass
    else:
        for a_table in child_table:
            class_name = a_table[0]
            class_fld = a_table[1]
            parclass = a_table[2]
            selfid = a_table[3]
            titr_color = a_table[4]
            value_color = a_table[5]

            query = 'SELECT ' + selfid + ' FROM ' + class_name + \
                ' WHERE ' + class_fld + " = '" + table_id + "'"
            cursor.execute(query)
            if cursor.rowcount == 0:
                pass
            else:
                table_ids_res = cursor.fetchall()
                for id in table_ids_res:
                    id = str(id[0])
                    row, prev_rec = checkTables(
                        class_name, id, sheet, cursor, cursor1, row, col + 1, prev_rec, titr_color, value_color)
    return row, prev_rec


def ContainerFunc(cursor , cursor_extra , table_name , dispach_code , fileName , address):
    try:
        excel_style_dict = config_parser_var()
        titr_color = excel_style_dict['title_color']
        value_color = excel_style_dict['body_color']
        titr_color = '(9, 41, 156)'
        value_color = '(63, 95, 209)'
        wb = openpyxl.Workbook()
        sheet = wb.active
        sheet.sheet_view.rightToLeft = True
        checkTables(table_name, dispach_code, sheet, cursor, cursor_extra, 1, 1,None ,titr_color ,value_color)
        wb.save(address+fileName)
        return True
    except Exception as e:
        print(f"Excel Error : {e}")
        return False

##### Name: IntelliJ IDEA Keybindings