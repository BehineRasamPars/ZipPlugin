# General tools for my own use.

import sys, os, os.path
import time, datetime
import csv



def strToList(input):
    outList = []
    reader = csv.reader(input.split('\n'), delimiter=',')
    for row in reader:
        outList = row
    outList = list(map(str.strip, outList))
    return outList


def listToStr(input, quoteWrap = False):
    if not quoteWrap:
        outStr = ','.join(input)
    else:
        outStr = ','.join(f"'{w}'" for w in input)
    return outStr


# Get path of application directory.
def getAppDir():

    # Determine if application is a script file or frozen exe
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    elif __file__:
        application_path = os.path.dirname(__file__)

    return application_path


def is_number(n):
    if n is None:
        return False
    try:
        float(n)   # Type-casting the string to `float`.
                   # If string is not a valid `float`, 
                   # it'll raise `ValueError` exception
    except ValueError:
        return False
    return True