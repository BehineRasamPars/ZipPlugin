import sys, os, os.path
import logging
import configparser
import psycopg2, psycopg2.extras
from psycopg2 import sql
from .mylib import *
#========================================================

class DataAccess:

    conf = {}


    def __init__(self):
        self.updateConf()


    # Get a connection to the database.
    def getConnElect(self):
        try:
            conn = psycopg2.connect(user = self.conf['DB_user'],
                            password = self.conf['DB_pass'],
                            host = self.conf['DB_host'],
                            port = self.conf['DB_port'],
                            dbname = 'electricity_red')
            conn.autocommit = True
            return conn
        except Exception as e:
            logging.error(e)
            return False

    def getCursor(self):
        return self.getConnElect().cursor()

    def getCursorExtras(self):
        return self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    
    def setConf(self): # Set self.conf.

        self.conf['mainPath'] = getAppDir()
        self.conf['confFilePath'] = self.conf['mainPath'] + '\\main.conf'
        self.conf['logPath'] = self.conf['mainPath'] + '\\main.log'

        confFile = configparser.ConfigParser()
        confFile.read(self.conf['confFilePath'])
        self.conf['fileLogging'] = confFile.getboolean('Main', 'file_logging')
        self.conf['DB_host'] = confFile['DB']['host']
        self.conf['DB_port'] = confFile['DB']['port']
        self.conf['DB_user'] = confFile['DB']['user']
        self.conf['DB_pass'] = confFile['DB']['pass']

    def updateConf(self):

        self.setConf()

        # File logging:
        if self.conf['fileLogging']:
            logging.basicConfig(filename=self.conf['logPath'],
                format='%(asctime)s | %(levelname)s | %(message)s', level=logging.INFO)
        else:
            logging.disable()

    def getTableList(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT table_name AS name_en, smtablename AS name_fa FROM table_list tl
                    LEFT JOIN smregister s ON (tl.table_name = s.smdatasetname)
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getPostList(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT * FROM (
                    SELECT DISTINCT ON (subst_code)
                        subf_name, subst_code, COALESCE(substat.conv_ratio, tank.conv_ratio) AS conv_ratio, substat.smid
                        FROM substat
                    LEFT JOIN
                        pow_tran USING (subst_code)
                    LEFT JOIN
                        tank ON (pow_tran.ptran_id = tank.tra_rac_id)
                ) t1  ORDER BY subf_name;    
                """)
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def selectLocativTower(self , buffer_input , item_smid):
        try:
            cur = self.getCursor()
            query = """
                WITH geom as (select st_buffer(st_union(smgeometry),{buffer_size}) as geo from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '{smid}')) select tower.smid from tower inner join geom on st_intersects(geom.geo , tower.smgeometry)
            """.format(buffer_size=buffer_input , smid = item_smid)
            cur.execute(query)
            res = []
            for a_smid in cur.fetchall():
                res.append(a_smid[0])
            return res
        except Exception as e:
            print(e)
            return None

    def selectDescriptivetower(self , item_smid):
        try:
            cur = self.getCursor()
            query = """
                SELECT tower_id FROM tower_OvPat_Seg WHERE ovpasg_id in (select ovpasg_id from cir_seg where cisec_id in (select cirsec_id from cir_sec where circt_id = '{smid}'))
            """.format(smid = item_smid)
            print(query)
            cur.execute(query)
            descriptive_tower = cur.fetchall()
            return descriptive_tower
        except Exception as e:
            print(e)
            return None

    def getCircuitList(self):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("SELECT cir_name, circt_id, nomi_vol, smid FROM circuit ORDER BY cir_name")
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getTableIds(self, main_table, con_table, con_idvalue):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                SELECT * FROM UNNEST(get_ids(%s, %s, %s))
                """, (main_table, con_table, con_idvalue,))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def getRelatedTables(self, main_table, con_idvalue):
        try:
            cur = self.getConnElect().cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            cur.execute("""
                    SELECT * FROM UNNEST(get_related_tables(%s, %s))
                """, (main_table, con_idvalue,))
            rows = cur.fetchall()
            return rows
        except Exception as e:
            logging.error(e)
            return False

    def translate(self, inValue):
        cur = self.getConnElect().cursor()
        query = sql.SQL("SELECT smtablename FROM smregister WHERE smdatasetname = '" + inValue + "'")
        cur.execute(query)
        data = cur.fetchone()
        if data:
            data = data[0]
        else:
            data = None
        return data

    def isTableGeo(self, tableName):
        try:
            cur = self.getConnElect().cursor()
            query = sql.SQL("""
                    SELECT is_table_geo(%s)
                """)
            cur.execute(query, (tableName,))
            data = cur.fetchone()[0]
            return data
        except Exception as e:
            logging.error(e)
            return False
